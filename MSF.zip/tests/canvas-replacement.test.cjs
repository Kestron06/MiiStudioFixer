const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const sourcePath = path.join(__dirname, '..', 'content', 'preview.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const closingIife = '})();';
const instrumentedSource = `${source.slice(0, source.lastIndexOf(closingIife))}
	globalThis.__canvasPreview = {
		setRender(url) { previewMode = 'replace'; readyCanvasRenderUrl = url; },
		setMode(mode) { previewMode = mode; syncCanvasReplacement(); },
		getMode() { return previewMode; },
		async renderReplacement(url) {
			await Promise.resolve();
			previewMode = 'replace';
			const snapshot = { data: 'current-mii', fingerprint: 'editor-key\u0000current-mii' };
			getStudioMiiSnapshot = () => snapshot;
			getRenderUrl = async () => url;
			await renderPreview(snapshot);
		},
		setPreviewMode,
		syncCanvasReplacement,
		removeCanvasReplacement,
		current() { return canvasReplacement; }
	};
${closingIife}`;

function makeStyle() {
	const values = new Map();
	return {
		getPropertyValue: name => values.get(name)?.value ?? '',
		getPropertyPriority: name => values.get(name)?.priority ?? '',
		setProperty(name, value, priority = '') {
			if (value) values.set(name, { value, priority });
			else values.delete(name);
		}
	};
}

function makeCanvas(parent, { left = 12, top = 24, width = 550, height = 550 } = {}) {
	const attributes = new Set();
	return {
		tagName: 'CANVAS', parentElement: parent, isConnected: true,
		offsetLeft: left, offsetTop: top, offsetWidth: width, offsetHeight: height,
		attributes,
		setAttribute: name => attributes.add(name),
		removeAttribute: name => attributes.delete(name),
		after(host) { host.isConnected = true; host.parentElement = parent; }
	};
}

function makeElement(tagName) {
	const element = {
		tagName: tagName.toUpperCase(),
		style: {},
		children: [],
		isConnected: false,
		setAttribute() {},
		removeAttribute() {},
		appendChild(child) { this.children.push(child); child.parentElement = this; },
		remove() { this.isConnected = false; this.parentElement = null; }
	};
	if (tagName === 'img') {
		element.removeAttribute = name => { if (name === 'src') element.src = ''; };
	}
	return element;
}

function createHarness() {
	const parent = { style: makeStyle() };
	const document = {
		canvas: makeCanvas(parent),
		getElementById(id) { return id === 'canvas' ? this.canvas : null; },
		createElement: makeElement,
		addEventListener() {}
	};
	const context = {
		document,
		window: { addEventListener() {} },
		chrome: { storage: { onChanged: { addListener() {} }, local: { get: async () => ({}) } } },
		getComputedStyle: () => ({ position: 'static' }),
		ResizeObserver: class { observe() {} disconnect() {} },
		clearTimeout() {},
		setTimeout() { return 1; },
		clearInterval() {},
		console
	};
	vm.runInNewContext(instrumentedSource, context, { filename: sourcePath });
	return { preview: context.__canvasPreview, document, parent };
}

test('canvas stays visible until the full body image loads, then follows its geometry', () => {
	const { preview, document, parent } = createHarness();
	preview.setRender('https://studio.mii.nintendo.com/miis/image.png?type=all_body');
	preview.syncCanvasReplacement();
	const current = preview.current();
	assert.equal(current.host.style.visibility, 'hidden');
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), false);
	assert.equal(parent.style.getPropertyValue('position'), 'relative');
	assert.equal(current.host.style.left, '12px');
	assert.equal(current.host.style.width, '550px');

	current.pendingImage.onload();
	assert.equal(current.host.style.visibility, 'visible');
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), true);
	document.canvas.offsetTop = 48;
	document.canvas.offsetWidth = 420;
	preview.syncCanvasReplacement();
	assert.equal(current.host.style.top, '48px');
	assert.equal(current.host.style.width, '420px');
});

test('canvas replacement rebinds to a new editor canvas and restores the old one', () => {
	const { preview, document, parent } = createHarness();
	preview.setRender('https://studio.mii.nintendo.com/miis/image.png?type=all_body');
	preview.syncCanvasReplacement();
	const oldCanvas = document.canvas;
	preview.current().pendingImage.onload();
	document.canvas = makeCanvas(parent, { left: 30, width: 400 });
	preview.syncCanvasReplacement();
	assert.equal(oldCanvas.attributes.has('data-real-mii-preview-hidden'), false);
	assert.equal(preview.current().host.style.left, '30px');
	preview.current().pendingImage.onload();
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), true);
	preview.removeCanvasReplacement();
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), false);
	assert.equal(parent.style.getPropertyValue('position'), '');
});

test('failed replacement restores the native canvas instead of showing an old Mii', () => {
	const { preview, document } = createHarness();
	preview.setRender('https://studio.mii.nintendo.com/miis/image.png?data=first&type=all_body');
	preview.syncCanvasReplacement();
	preview.current().pendingImage.onload();
	preview.setRender('https://studio.mii.nintendo.com/miis/image.png?data=second&type=all_body');
	preview.syncCanvasReplacement();
	preview.current().pendingImage.onerror();
	assert.equal(preview.current(), null);
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), false);
	preview.syncCanvasReplacement();
	assert.equal(preview.current(), null);
});

test('floating mode leaves the editor canvas visible and removes a prior replacement', () => {
	const { preview, document } = createHarness();
	preview.setRender('https://studio.mii.nintendo.com/miis/image.png?type=all_body');
	preview.syncCanvasReplacement();
	preview.current().pendingImage.onload();
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), true);
	preview.setMode('floating');
	assert.equal(preview.current(), null);
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), false);
	preview.syncCanvasReplacement();
	assert.equal(preview.current(), null);
});

test('off mode removes a loaded canvas replacement', () => {
	const { preview, document } = createHarness();
	preview.setRender('https://studio.mii.nintendo.com/miis/image.png?type=all_body');
	preview.syncCanvasReplacement();
	preview.current().pendingImage.onload();
	preview.setPreviewMode('off');
	assert.equal(preview.getMode(), 'off');
	assert.equal(preview.current(), null);
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), false);
});

test('replacement render starts an image without creating the floating overlay', async () => {
	const { preview, document } = createHarness();
	await preview.renderReplacement('https://studio.mii.nintendo.com/miis/image.png?type=all_body');
	assert.ok(preview.current()?.pendingImage);
	assert.equal(document.canvas.attributes.has('data-real-mii-preview-hidden'), false);
});
