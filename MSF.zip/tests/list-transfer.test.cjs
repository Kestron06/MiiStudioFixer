const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'content', 'list.js'), 'utf8');
const key = 'mii-studio-fixer-stored-miis-v1';
const data = '06042c030c04020f030b020604020c03080000080000000804000a06002f7f040002140313040f0d040407040107';
const restored = { id: 'stored-1', name: 'Restored', data };
const another = { id: 'stored-2', name: 'Keep', data };

class CustomEvent {
	constructor(type, options = {}) { this.type = type; this.detail = options.detail; }
}

function harness(receipt = null) {
	const listeners = new Map();
	const acks = [];
	let entries = [restored, another];
	let writes = 0;
	const document = {
		documentElement: {}, body: {},
		getElementById() { return null; },
		querySelector() { return null; },
		querySelectorAll() { return []; },
		addEventListener(type, listener) { listeners.set(type, [...(listeners.get(type) || []), listener]); },
		removeEventListener(type, listener) {
			listeners.set(type, (listeners.get(type) || []).filter(value => value !== listener));
		},
		dispatchEvent(event) {
			if (event.type === 'mii-studio-fixer:restore-success-request') {
				this.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-success-result', {
					detail: { id: event.detail.id, ...(receipt || {}) }
				}));
			}
			if (event.type === 'mii-studio-fixer:restore-success-ack') acks.push(event.detail);
			for (const listener of listeners.get(event.type) || []) listener(event);
		}
	};
	const sessionStorage = { getItem() { return null; }, removeItem() {} };
	const chrome = {
		storage: {
			local: {
				async get() { return { [key]: entries }; },
				async set(value) { entries = value[key]; writes++; }
			},
			onChanged: { addListener() {} }
		}
	};
	class MutationObserver { observe() {} }
	vm.runInNewContext(source, {
		CustomEvent, MutationObserver, URL, document, sessionStorage, chrome,
		location: new URL('https://studio.mii.nintendo.com/miis/0123456789abcdef/edit?client_id=b2486001c0980130'),
		crypto: { randomUUID() { return 'receipt-request'; } },
		setTimeout, clearTimeout, setInterval() {},
		console: { warn() {} }
	});
	return {
		document,
		get entries() { return entries; },
		get writes() { return writes; },
		acks,
		async settle() { await new Promise(resolve => setImmediate(resolve)); }
	};
}

test('a confirmed restore removes only its exact stored entry', async () => {
	const page = harness({ entryId: restored.id, data });
	await page.settle();
	assert.deepEqual(page.entries, [another]);
	assert.equal(page.writes, 1);
	assert.equal(page.acks.length, 1);
	assert.equal(page.acks[0].entryId, restored.id);
});

test('a restore without save confirmation leaves the stored Mii available', async () => {
	const page = harness();
	page.document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-result', {
		detail: { status: 'full', entryId: restored.id, data }
	}));
	await page.settle();
	assert.deepEqual(page.entries, [restored, another]);
	assert.equal(page.writes, 0);
	assert.equal(page.acks.length, 0);
});

test('a mismatched success receipt cannot remove another stored Mii', async () => {
	const page = harness({ entryId: restored.id, data: 'ab'.repeat(46) });
	await page.settle();
	assert.deepEqual(page.entries, [restored, another]);
	assert.equal(page.writes, 0);
});

function storeResumeHarness({ storedEntries = [restored], menuId = '0123456789abcdef' } = {}) {
	const miiId = '0123456789abcdef';
	const imageData = 'bdc2cde8f2050811252d2d36373a3f3a404f565d5c636a71808b929fa0a78ff7fa010a252d45484e4a555866696f6f';
	const listeners = new Map();
	const session = new Map([['mii-studio-fixer-pending-store-v1', JSON.stringify({
		phase: 'erase', miiId, entryId: restored.id, tileIndex: 0, createdAt: Date.now()
	})]]);
	let tileClicks = 0;
	let imageClicks = 0;
	let eraseClicks = 0;
	let deleteClicks = 0;
	let now = 1000;
	const tile = {
		click() { tileClicks++; }, parentElement: null,
		closest() { return null; },
		querySelector(selector) { return selector === '.c-mii-btn__img' ? image : null; }
	};
	const image = {
		src: `https://studio.mii.nintendo.com/miis/image.png?data=${imageData.slice(0, -2)}00`,
		parentElement: tile,
		closest(selector) { return selector === '.c-mii-btn' ? tile : null; },
		click() { imageClicks++; }
	};
	const menu = {
		parentElement: null,
		querySelectorAll() { return imageClicks >= 2 && !eraseClicks ? [edit, erase, close] : []; }
	};
	function action(text, href = '') {
		return {
			textContent: text, parentElement: menu,
			closest() { return null; },
			getAttribute(name) { return name === 'href' ? href : null; }
		};
	}
	const edit = action('Edit', `/miis/${menuId}/edit`);
	const erase = action('Erase');
	erase.click = () => { eraseClicks++; };
	const close = action('Close');
	function fakeElement() {
		return {
			children: [], addEventListener() {}, setAttribute() {}, focus() {}, remove() {},
			append(...children) { this.children.push(...children); },
			querySelectorAll() { return []; }
		};
	}
	const document = {
		documentElement: {}, body: { append() {} },
		getElementById() { return null; },
		querySelector() { return null; },
		createElement() { return fakeElement(); },
		querySelectorAll(selector) {
			if (selector === '.c-mii-btn') return [tile];
			if (selector === 'img[src]') return [image];
			if (selector === 'button, a, [role="button"], [tabindex]') return imageClicks >= 2 && !eraseClicks ? [edit, erase, close] : [];
			return [];
		},
		addEventListener(type, listener) { listeners.set(type, [...(listeners.get(type) || []), listener]); },
		removeEventListener(type, listener) {
			listeners.set(type, (listeners.get(type) || []).filter(value => value !== listener));
		},
		dispatchEvent(event) {
			if (event.type === 'mii-studio-fixer:restore-success-request') {
				this.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-success-result', { detail: { id: event.detail.id } }));
			}
			if (event.type === 'mii-studio-fixer:store-delete-request') {
				this.dispatchEvent(new CustomEvent('mii-studio-fixer:store-delete-result', {
					detail: { id: event.detail.id, status: 'unavailable' }
				}));
			}
			for (const listener of listeners.get(event.type) || []) listener(event);
		}
	};
	class FakeDate extends Date { static now() { return now; } }
	class MutationObserver { observe() {} }
	vm.runInNewContext(source, {
		CustomEvent, MutationObserver, URL, Date: FakeDate, document,
		location: new URL('https://studio.mii.nintendo.com/?client_id=b2486001c0980130'),
		chrome: { storage: {
			local: { async get() { return { [key]: storedEntries }; } },
			onChanged: { addListener() {} }
		} },
		sessionStorage: {
			getItem(name) { return session.get(name) ?? null; },
			setItem(name, value) { session.set(name, value); },
			removeItem(name) { session.delete(name); }
		},
		crypto: { randomUUID() { return 'request'; } },
		getComputedStyle() { return { display: 'block', visibility: 'visible' }; },
		setTimeout(callback, delay) {
			if (delay === 150) { now += delay; queueMicrotask(callback); return 0; }
			return setTimeout(callback, delay);
		},
		clearTimeout, setInterval() {}, console: { warn() {} }
	});
	return {
		async settle() { await new Promise(resolve => setImmediate(resolve)); },
		setStoredEntries(value) { storedEntries = value; },
		openDeletePage(routeId = miiId) {
			const formListeners = new Map();
			const form = {
				parentElement: null,
				closest() { return null; },
				querySelectorAll() { return [submit, cancel]; },
				querySelector(selector) { return selector === '.c-action__btn' ? submit : null; },
				addEventListener(type, listener) { formListeners.set(type, listener); },
				requestSubmit() { deleteClicks++; formListeners.get('submit')?.({ type: 'submit' }); }
			};
			const submit = {
				textContent: 'Erase', className: 'c-action__btn', tagName: 'BUTTON', type: 'submit', parentElement: form,
				click() { deleteClicks++; formListeners.get('submit')?.({ type: 'submit' }); },
				getAttribute(name) { return name === 'type' ? 'submit' : null; },
				closest() { return null; }
			};
			const cancel = {
				textContent: 'Cancel', tagName: 'BUTTON', parentElement: form,
				click() { throw new Error('Cancel must not be clicked'); },
				getAttribute() { return null; },
				closest() { return null; }
			};
			const deleteDocument = {
				documentElement: {}, body: { dataset: { pageId: 'mii-delete' }, append() {} },
				getElementById() { return null; },
				querySelector(selector) { return selector === 'form' ? form : null; },
				querySelectorAll(selector) {
					if (selector === 'form') return [form];
					return selector === 'button, a, [role="button"], [tabindex]' ? [submit, cancel] : [];
				},
				createElement() { return fakeElement(); },
				addEventListener() {}, removeEventListener() {}, dispatchEvent() {}
			};
			vm.runInNewContext(source, {
				CustomEvent, MutationObserver, URL, Date: FakeDate, document: deleteDocument,
				location: new URL(`https://studio.mii.nintendo.com/miis/${routeId}/delete?client_id=b2486001c0980130`),
				chrome: { storage: {
					local: { async get() { return { [key]: storedEntries }; } },
					onChanged: { addListener() {} }
				} },
				sessionStorage: {
					getItem(name) { return session.get(name) ?? null; },
					setItem(name, value) { session.set(name, value); },
					removeItem(name) { session.delete(name); }
				},
				crypto: { randomUUID() { return 'request'; } },
				getComputedStyle() { return { display: 'block', visibility: 'visible' }; },
				setTimeout(callback, delay) {
					if (delay === 150) { now += delay; queueMicrotask(callback); return 0; }
					return setTimeout(callback, delay);
				},
				clearTimeout, setInterval() {}, console: { warn() {} }
			});
		},
		get tileClicks() { return tileClicks; },
		get imageClicks() { return imageClicks; },
		get eraseClicks() { return eraseClicks; },
		get deleteClicks() { return deleteClicks; },
		get pending() { return session.get('mii-studio-fixer-pending-store-v1'); }
	};
}

test('Store reopens the selected tile and confirms native delete page after verifying the stored Mii', async () => {
	const page = storeResumeHarness();
	await page.settle();
	assert.ok(page.imageClicks >= 2, `tile clicks: ${page.tileClicks}, image clicks: ${page.imageClicks}`);
	assert.equal(page.tileClicks, 0);
	assert.equal(page.eraseClicks, 1);
	assert.equal(JSON.parse(page.pending).phase, 'confirm-erase');
	page.openDeletePage();
	await page.settle();
	assert.equal(page.deleteClicks, 1);
	assert.equal(page.pending, undefined);
});

test('Store never confirms Erase when the selected menu belongs to a different Mii', async () => {
	const page = storeResumeHarness({ menuId: 'fedcba9876543210' });
	await page.settle();
	assert.equal(page.eraseClicks, 0);
	page.openDeletePage();
	await page.settle();
	assert.equal(page.deleteClicks, 0);
});

test('Store never starts Erase if its extension copy is unavailable', async () => {
	const page = storeResumeHarness({ storedEntries: [] });
	await page.settle();
	assert.equal(page.eraseClicks, 0);
	page.openDeletePage();
	await page.settle();
	assert.equal(page.deleteClicks, 0);
});

test('Store does not confirm a different Mii on the native delete page', async () => {
	const page = storeResumeHarness();
	await page.settle();
	assert.equal(page.eraseClicks, 1);
	page.openDeletePage('fedcba9876543210');
	await page.settle();
	assert.equal(page.deleteClicks, 0);
});

test('Store leaves the native delete page alone if the saved extension copy disappears', async () => {
	const page = storeResumeHarness();
	await page.settle();
	assert.equal(page.eraseClicks, 1);
	page.setStoredEntries([]);
	page.openDeletePage();
	await page.settle();
	assert.equal(page.deleteClicks, 0);
});

function silentListHarness({ storeStatus = 'deleted', restoreStatus = 'saved', storedEntries = [restored, another],
	editWrapper = false, captureStatus = 'captured', full = false, fileStatus = 'ready',
	capacityStatus = 'available', createLabel = 'Create Mii' } = {}) {
	const miiId = '0123456789abcdef';
	const listeners = new Map();
	const requests = [];
	const captureDetails = [];
	const createDetails = [];
	const exports = [];
	const acks = [];
	const session = new Map();
	let reloads = 0;
	let eraseClicks = 0;
	let createClicks = 0;
	let writes = 0;
	let entries = [...storedEntries];
	class Element {
		constructor(tagName = 'div') {
			this.tagName = tagName.toUpperCase();
			this.children = [];
			this.listeners = new Map();
			this.attributes = new Map();
			this.classList = { add() {}, contains() { return false; } };
			this.parentElement = null;
			this.textContent = '';
			this.isConnected = true;
		}
		append(...children) {
			for (const child of children) { child.parentElement = this; this.children.push(child); }
		}
		remove() {
			if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this);
			this.isConnected = false;
		}
		before(sibling) {
			const children = this.parentElement?.children;
			if (!children) return;
			sibling.parentElement = this.parentElement;
			children.splice(children.indexOf(this), 0, sibling);
		}
		cloneNode() {
			const copy = new Element(this.tagName);
			copy.textContent = this.textContent;
			copy.attributes = new Map(this.attributes);
			return copy;
		}
		addEventListener(type, listener) { this.listeners.set(type, [...(this.listeners.get(type) || []), listener]); }
		click() { for (const listener of this.listeners.get('click') || []) listener({
			target: this, preventDefault() {}, stopImmediatePropagation() {}
		}); }
		focus() {}
		setAttribute(name, value) { this.attributes.set(name, value); }
		getAttribute(name) { return this.attributes.get(name) ?? null; }
		removeAttribute(name) { this.attributes.delete(name); }
		matches(selector) { return selector.split(',').some(part => part.trim().toUpperCase() === this.tagName); }
		closest() { return null; }
		get nextElementSibling() {
			const children = this.parentElement?.children || [];
			return children[children.indexOf(this) + 1] || null;
		}
		querySelectorAll(selector) {
			const descendants = this.children.flatMap(child => [child, ...child.querySelectorAll('*')]);
			return selector === '*' ? descendants : descendants.filter(child =>
				(selector === 'button' && child.tagName === 'BUTTON')
				|| (selector === 'a[href]' && child.tagName === 'A' && child.getAttribute('href'))
				|| (selector === 'button, a, [role="button"], [tabindex]'
					&& ['BUTTON', 'A'].includes(child.tagName)));
		}
		querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
		get firstElementChild() { return this.children[0] || null; }
	}
	const body = new Element('body');
	if (full) body.innerText = "So many Mii characters! You'll need to manage them before you can create a new one.";
	const menu = new Element();
	const edit = new Element(editWrapper ? 'div' : 'a');
	edit.textContent = 'Edit';
	if (!editWrapper) edit.setAttribute('href', `/miis/${miiId}/edit`);
	if (editWrapper === 'descendant') {
		const link = new Element('a');
		link.setAttribute('href', `/miis/${miiId}/edit?client_id=b2486001c0980130`);
		edit.append(link);
	}
	const erase = new Element('button');
	erase.textContent = 'Erase';
	erase.setAttribute('href', `/miis/${miiId}/delete`);
	erase.click = () => { eraseClicks++; };
	const close = new Element('button');
	close.textContent = 'Close';
	menu.append(edit, erase, close);
	const back = new Element('button');
	back.textContent = 'Back';
	const create = new Element('a');
	create.textContent = createLabel;
	create.setAttribute('href', '/miis/new?client_id=b2486001c0980130');
	create.click = () => {
		createClicks++;
		document.dispatchEvent({ type: 'click', target: create, isTrusted: false,
			preventDefault() {}, stopImmediatePropagation() {} });
	};
	create.closest = selector => /(?:^|,)\s*a\b|\[href\]|miis\/new/i.test(selector) ? create : null;
	body.append(menu, create, back);
	const tile = new Element('button');
	tile.setAttribute('data-modal', `mii-${miiId}`);
	tile.closest = selector => selector === '.c-mii-btn' ? tile : null;
	const document = {
		documentElement: new Element(), body,
		createElement(tagName) { return new Element(tagName); },
		getElementById(id) { return body.querySelectorAll('*').find(element => element.id === id) || null; },
		querySelector() { return null; },
		querySelectorAll(selector) {
			if (selector === '.c-mii-btn') return [tile];
			return selector === 'button, a, [role="button"], [tabindex]'
				? body.querySelectorAll('*').filter(element => ['BUTTON', 'A'].includes(element.tagName)) : [];
		},
		addEventListener(type, listener) { listeners.set(type, [...(listeners.get(type) || []), listener]); },
		removeEventListener(type, listener) {
			listeners.set(type, (listeners.get(type) || []).filter(value => value !== listener));
		},
		dispatchEvent(event) {
			requests.push(event.type);
			let resultEvent;
			let detail;
			if (event.type === 'mii-studio-fixer:restore-success-request') {
				resultEvent = 'mii-studio-fixer:restore-success-result'; detail = { id: event.detail.id };
			} else if (event.type === 'mii-studio-fixer:store-capture-request') {
				captureDetails.push(event.detail);
				resultEvent = 'mii-studio-fixer:store-capture-result';
				detail = { id: event.detail.id, status: captureStatus, miiId, data };
			} else if (event.type === 'mii-studio-fixer:store-delete-request') {
				resultEvent = 'mii-studio-fixer:store-delete-result';
				detail = { id: event.detail.id, status: storeStatus };
			} else if (event.type === 'mii-studio-fixer:restore-capacity-request') {
				resultEvent = 'mii-studio-fixer:restore-capacity-result';
				detail = { id: event.detail.id, status: capacityStatus };
			} else if (event.type === 'mii-studio-fixer:restore-create-request') {
				createDetails.push(event.detail);
				resultEvent = 'mii-studio-fixer:restore-create-result';
				detail = { id: event.detail.id, status: restoreStatus, entryId: restored.id, data };
			} else if (event.type === 'mii-studio-fixer:import-file-request') {
				resultEvent = 'mii-studio-fixer:import-file-result';
				detail = { id: event.detail.id, status: fileStatus, data };
			} else if (event.type === 'mii-studio-fixer:restore-request') {
				resultEvent = 'mii-studio-fixer:restore-result';
				detail = { id: event.detail.id, status: 'started' };
			} else if (event.type === 'mii-studio-fixer:restore-success-ack') {
				acks.push(event.detail);
			}
			if (resultEvent) this.dispatchEvent(new CustomEvent(resultEvent, { detail }));
			for (const listener of listeners.get(event.type) || []) listener(event);
		}
	};
	class MutationObserver { observe() {} }
	const location = new URL('https://studio.mii.nintendo.com/?client_id=b2486001c0980130');
	location.reload = () => { reloads++; };
	const exposed = source.replace(/\n\}\)\(\);\s*$/,
		'\nObject.assign(globalThis, { __listTest: { showStoreDialog, showRestoreDialog, showCreateMenu, startImport, refreshExportOption } });\n})();');
	assert.notEqual(exposed, source, 'could not expose list UI functions for the VM test');
	const context = {
		CustomEvent, MutationObserver, URL, document, location,
		MiiStudioFixerExport: { async show(options) { exports.push(options); } },
		chrome: { storage: {
			local: {
				async get() { return { [key]: entries }; },
				async set(value) { entries = value[key]; writes++; }
			},
			onChanged: { addListener() {} }
		} },
		sessionStorage: {
			getItem(name) { return session.get(name) ?? null; },
			setItem(name, value) { session.set(name, value); },
			removeItem(name) { session.delete(name); }
		},
		crypto: { randomUUID() { return `request-${requests.length}`; } },
		getComputedStyle() { return { display: 'block', visibility: 'visible' }; },
		setTimeout, clearTimeout, setInterval() {}, console: { warn() {} }
	};
	vm.runInNewContext(exposed, context);
	return {
		async settle() { await new Promise(resolve => setImmediate(resolve)); },
		openStore() { context.__listTest.showStoreDialog({ edit, erase, close }); },
		openCreate() { context.__listTest.showCreateMenu(create); },
		selectCreate() { document.dispatchEvent({ type: 'click', target: create, isTrusted: true,
			preventDefault() {}, stopImmediatePropagation() {} }); },
		pressEscape() { document.dispatchEvent({ type: 'keydown', key: 'Escape', stopPropagation() {} }); },
		clickCreateOverlay() { body.querySelectorAll('*').find(element => element.className === 'o-modal__overlay')?.click(); },
		showExportButton() { context.__listTest.refreshExportOption(); },
		selectTile() { document.dispatchEvent({ type: 'click', target: tile }); },
		async openRestore() { await context.__listTest.showRestoreDialog(); },
		button(label) {
			return body.querySelectorAll('button').filter(button => button.textContent === label).at(-1);
		},
		get createMenuLabels() {
			return document.getElementById('mii-studio-fixer-create-modal')?.querySelectorAll('button')
				.map(button => button.textContent) || [];
		},
		get listDialogLabels() {
			return document.getElementById('mii-studio-fixer-list-dialog')?.querySelectorAll('button')
				.map(button => button.textContent) || [];
		},
		get createModal() { return document.getElementById('mii-studio-fixer-create-modal'); },
		get createClicks() { return createClicks; },
		setName(value) { body.querySelectorAll('*').find(element => element.tagName === 'INPUT').value = value; },
		get requests() { return requests; },
		get captureDetails() { return captureDetails; },
		get createDetails() { return createDetails; },
		get exports() { return exports; },
		get entries() { return entries; },
		get writes() { return writes; },
		get reloads() { return reloads; },
		get eraseClicks() { return eraseClicks; },
		get acks() { return acks; },
		get pending() { return session.get('mii-studio-fixer-pending-store-v1'); },
		get error() { return body.querySelectorAll('*').find(element => element.className === 'mii-studio-fixer-error')?.textContent; },
		get message() { return body.querySelectorAll('*').find(element => element.className === 'mii-studio-fixer-message')?.textContent; }
	};
}

test('silent Store saves a verified copy and deletes on the list page', async () => {
	const page = silentListHarness();
	await page.settle();
	page.openStore();
	page.setName('Stored');
	page.button('Store').click();
	await page.settle();
	assert.equal(page.entries.length, 3);
	assert.equal(page.entries[2].name, 'Stored');
	assert.ok(page.requests.includes('mii-studio-fixer:store-delete-request'));
	assert.equal(page.reloads, 1);
	assert.equal(page.eraseClicks, 0);
	assert.equal(page.pending, undefined);
});

test('Store identifies the selected tile when the Edit menu action has no link', async () => {
	const page = silentListHarness({ editWrapper: true, captureStatus: 'error' });
	await page.settle();
	page.selectTile();
	page.openStore();
	page.setName('Stored');
	page.button('Store').click();
	await page.settle();
	assert.equal(page.captureDetails.length, 1);
	const capture = page.captureDetails[0];
	assert.equal(capture.miiId, '0123456789abcdef');
	assert.equal(capture.tileIndex, 0);
	const editUrl = new URL(capture.editUrl, 'https://studio.mii.nintendo.com/?client_id=b2486001c0980130');
	assert.equal(editUrl.pathname, '/miis/0123456789abcdef/edit');
	assert.equal(editUrl.searchParams.get('client_id'), 'b2486001c0980130');
});

test('Store reads an Edit link nested inside a menu action', async () => {
	const page = silentListHarness({ editWrapper: 'descendant', captureStatus: 'error' });
	await page.settle();
	page.selectTile();
	page.openStore();
	page.setName('Stored');
	page.button('Store').click();
	await page.settle();
	const capture = page.captureDetails[0];
	assert.equal(capture.miiId, '0123456789abcdef');
	assert.equal(new URL(capture.editUrl, 'https://studio.mii.nintendo.com').searchParams.get('client_id'),
		'b2486001c0980130');
});

test('silent Store unavailable falls back to native Erase', async () => {
	const page = silentListHarness({ storeStatus: 'unavailable' });
	await page.settle();
	page.openStore();
	page.setName('Stored');
	page.button('Store').click();
	await page.settle();
	assert.equal(page.eraseClicks, 1);
	assert.equal(page.reloads, 0);
	assert.equal(JSON.parse(page.pending).phase, 'confirm-erase');
});

test('silent Restore removes only the confirmed stored Mii and stays on the list page', async () => {
	const page = silentListHarness();
	await page.settle();
	await page.openRestore();
	page.button('Restored').click();
	await page.settle();
	assert.deepEqual(page.entries, [another]);
	assert.equal(page.writes, 1);
	assert.equal(page.reloads, 1);
	assert.equal(page.acks.length, 1);
	assert.ok(!page.requests.includes('mii-studio-fixer:restore-request'));
});

test('uncertain silent Restore preserves the stored Mii and does not start native fallback', async () => {
	const page = silentListHarness({ restoreStatus: 'uncertain' });
	await page.settle();
	await page.openRestore();
	page.button('Restored').click();
	await page.settle();
	assert.deepEqual(page.entries, [restored, another]);
	assert.equal(page.writes, 0);
	assert.equal(page.reloads, 0);
	assert.ok(!page.requests.includes('mii-studio-fixer:restore-request'));
	assert.match(page.error, /Refresh the saved Mii list before trying again/);
});

test('Create Mii opens Create, Restore, Import, Close without changing the Back controls', async () => {
	const page = silentListHarness();
	await page.settle();
	assert.ok(page.button('Back'));
	assert.equal(page.button('Import Mii'), undefined);
	assert.equal(page.button('Restore stored Mii'), undefined);
	page.selectCreate();
	assert.deepEqual(page.createMenuLabels, ['Create', 'Restore', 'Import', 'Close']);
	assert.match(page.createModal.className, /\bo-modal c-mii-modal active\b/);
	assert.equal(page.createModal.getAttribute('role'), 'dialog');
	page.button('Close').click();
	assert.deepEqual(page.createMenuLabels, []);
	assert.equal(page.createClicks, 0);
});

test('the + control opens the same Create menu and Create follows the native action', async () => {
	const page = silentListHarness({ createLabel: '+' });
	await page.settle();
	page.selectCreate();
	assert.deepEqual(page.createMenuLabels, ['Create', 'Restore', 'Import', 'Close']);
	page.button('Create').click();
	assert.equal(page.createClicks, 1);
	assert.deepEqual(page.createMenuLabels, []);
});

test('the Create menu closes through its overlay and Escape key', async () => {
	const page = silentListHarness();
	await page.settle();
	page.selectCreate();
	page.clickCreateOverlay();
	assert.deepEqual(page.createMenuLabels, []);
	page.selectCreate();
	page.pressEscape();
	assert.deepEqual(page.createMenuLabels, []);
});

test('Restore in the Create menu opens the stored Mii choices', async () => {
	const page = silentListHarness();
	await page.settle();
	page.selectCreate();
	page.button('Restore').click();
	await page.settle();
	assert.deepEqual(page.listDialogLabels, ['Restored', 'Keep', 'Close']);
	page.button('Restored').click();
	await page.settle();
	assert.deepEqual(page.entries, [another]);
	assert.equal(page.reloads, 1);
});

test('Import in the Create menu opens the picker and creates its Mii silently', async () => {
	const page = silentListHarness();
	await page.settle();
	page.selectCreate();
	page.button('Import').click();
	await page.settle();
	assert.ok(page.requests.includes('mii-studio-fixer:import-file-request'));
	assert.equal(page.createDetails.length, 1);
	assert.equal(page.createDetails[0].source, 'import');
	assert.equal(page.createDetails[0].data, data);
	assert.equal(page.reloads, 1);
	assert.deepEqual(page.entries, [restored, another]);
	assert.equal(page.writes, 0);
	assert.ok(!page.requests.includes('mii-studio-fixer:restore-request'));
});

test('Import on a full list shows the Restore capacity message without opening the picker', async () => {
	const page = silentListHarness({ full: true });
	await page.settle();
	page.openCreate();
	page.button('Import').click();
	await page.settle();
	assert.equal(page.message,
		'One or more Miis will need to be stored or deleted before restoring any saved Miis.');
	assert.ok(!page.requests.includes('mii-studio-fixer:import-file-request'));
	assert.equal(page.createDetails.length, 0);
	assert.equal(page.reloads, 0);
});

test('Restore on a full list shows the existing capacity message', async () => {
	const page = silentListHarness({ full: true });
	await page.settle();
	page.openCreate();
	page.button('Restore').click();
	await page.settle();
	assert.equal(page.message,
		'One or more Miis will need to be stored or deleted before restoring any saved Miis.');
	assert.equal(page.createDetails.length, 0);
});

test('Import shows the Restore capacity message when the server reports a full list', async () => {
	const page = silentListHarness({ capacityStatus: 'full' });
	await page.settle();
	page.openCreate();
	page.button('Import').click();
	await page.settle();
	assert.ok(page.requests.includes('mii-studio-fixer:import-file-request'));
	assert.equal(page.message,
		'One or more Miis will need to be stored or deleted before restoring any saved Miis.');
	assert.equal(page.createDetails.length, 0);
	assert.equal(page.reloads, 0);
});

test('Export sends captured Mii data to file options without storing or erasing', async () => {
	const page = silentListHarness();
	await page.settle();
	page.showExportButton();
	page.button('Export').click();
	await page.settle();
	assert.equal(page.exports.length, 1);
	assert.equal(page.exports[0].data, data);
	assert.equal(page.captureDetails.length, 1);
	assert.ok(!page.requests.includes('mii-studio-fixer:store-delete-request'));
	assert.equal(page.eraseClicks, 0);
	assert.equal(page.writes, 0);
	assert.equal(page.reloads, 0);
});
