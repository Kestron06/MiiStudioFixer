const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const storePath = path.join(__dirname, '..', 'content', 'list-store.js');
const restorePath = path.join(__dirname, '..', 'content', 'list-restore.js');
const storeSource = fs.readFileSync(storePath, 'utf8');
const restoreSource = fs.readFileSync(restorePath, 'utf8');
const listUrl = 'https://studio.mii.nintendo.com/?client_id=b2486001c0980130';
const editUrl = 'https://studio.mii.nintendo.com/miis/0123456789abcdef/edit?client_id=b2486001c0980130';
const selectedId = '0123456789abcdef';
const otherId = 'fedcba9876543210';
const storedId = 'stored-mii-1';
// The image data is the concrete Nintendo example supplied with the feature request.
const imageData = 'bdc2cde8f2050811252d2d36373a3f3a404f565d5c636a71808b929fa0a78ff7fa010a252d45484e4a555866696f6f';
const rawData = '06042c030c04020f030b020604020c03080000080000000804000a06002f7f040002140313040f0d040407040107';

function events() {
	const listeners = new Map();
	const emitted = [];
	return {
		emitted,
		addEventListener(type, listener) {
			listeners.set(type, [...(listeners.get(type) || []), listener]);
		},
		dispatchEvent(event) {
			emitted.push(event);
			for (const listener of listeners.get(event.type) || []) listener(event);
			return true;
		}
	};
}

class CustomEvent {
	constructor(type, options = {}) { this.type = type; this.detail = options.detail; }
}

class FakeNode {
	constructor({ href = '', parentElement = null, images = [], links = [], tagged = [], attributes = {}, vue = null } = {}) {
		this.href = href;
		this.parentElement = parentElement;
		this.images = images;
		this.links = links;
		this.tagged = tagged;
		this.attributes = attributes;
		this.__vue__ = vue;
	}
	querySelectorAll(selector) {
		if (selector === 'img[src]' || selector === '[data-src], img[src]') return this.images;
		if (selector === 'a[href]') return this.links;
		if (selector === '[data-mii-id], [data-id]') return this.tagged;
		return [];
	}
	getAttribute(name) { return this.attributes[name] ?? null; }
	contains(candidate) {
		for (let current = candidate; current; current = current.parentElement) {
			if (current === this) return true;
		}
		return false;
	}
	closest() { return null; }
}
class FakeWindow {}

function storeHarness({ links = [], roots = [], tagged = [], tiles = [], modals = {}, controls = [], body = new FakeNode(), canvas = null, url = listUrl, stored = {}, fetchResponse = null } = {}) {
	const document = Object.assign(events(), {
		body,
		getElementById(id) { return modals[id] || null; },
		querySelectorAll(selector) {
			if (selector === 'a[href]') return links;
			if (selector === 'button, a, [role="button"]') return controls;
			if (selector === '*') return roots;
			if (selector === '[data-mii-id], [data-id]') return tagged;
			if (selector === '.c-mii-btn') return tiles;
			return [];
		},
		querySelector(selector) { return selector === 'canvas#canvas' ? canvas : null; }
	});
	const storage = new Map(Object.entries(stored));
	const localStorage = {
		getItem(key) { return storage.get(key) ?? null; },
		setItem(key, value) { storage.set(key, value); }
	};
	const fetchCalls = [];
	class DOMParser {
		parseFromString(html) {
			const tag = /<body\b[^>]*>/i.exec(html)?.[0] || '';
			return { body: { getAttribute(name) {
				return new RegExp(`${name}="([^"]*)"`, 'i').exec(tag)?.[1] ?? null;
			} } };
		}
	}
	vm.runInNewContext(storeSource, {
		CustomEvent, Node: FakeNode, Window: FakeWindow, URL, Uint8Array,
		document, localStorage, location: new URL(url), DOMParser,
		fetch(requestUrl, options) {
			fetchCalls.push({ url: requestUrl, options });
			return fetchResponse ? fetchResponse(requestUrl, options) : Promise.reject(new Error('Network unavailable'));
		},
		console: { warn() {} }
	}, { filename: storePath });
	return {
		document, localStorage, fetchCalls,
		request(type, detail) {
			document.dispatchEvent(new CustomEvent(type, { detail }));
			return document.emitted.at(-1).detail;
		},
		requestAsync(type, detail) {
			return new Promise(resolve => {
				document.addEventListener('mii-studio-fixer:store-capture-result', event => {
					if (event.detail.id === detail.id) resolve(event.detail);
				});
				document.dispatchEvent(new CustomEvent(type, { detail }));
			});
		}
	};
}

function makeLink(id, image) {
	const imageNode = image ? new FakeNode({ href: image }) : null;
	if (imageNode) imageNode.src = image;
	const link = new FakeNode({
		href: `https://studio.mii.nintendo.com/miis/${id}/edit?client_id=b2486001c0980130`,
		images: imageNode ? [imageNode] : []
	});
	link.textContent = 'Edit';
	return link;
}

test('store capture decodes the supplied Nintendo image data for the selected Mii only', () => {
	const image = `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}&type=all_body`;
	const unrelated = makeLink(otherId, image);
	const selected = makeLink(selectedId, image);
	const harness = storeHarness({ links: [unrelated, selected] });
	const result = harness.request('mii-studio-fixer:store-capture-request', { id: 'req-1', miiId: selectedId });
	assert.equal(result.status, 'captured');
	assert.equal(result.miiId, selectedId);
	assert.equal(result.data, rawData);
});

test('store capture prefers the matching Vue record and does not use another Mii', () => {
	const otherData = '00'.repeat(46);
	const root = new FakeNode({ vue: { $data: { records: [
		{ id: otherId, data: otherData },
		{ id: selectedId, mii: { data: rawData } }
	] } } });
	const harness = storeHarness({ roots: [root] });
	const result = harness.request('mii-studio-fixer:store-capture-request', { id: 'req-2', miiId: selectedId });
	assert.equal(result.status, 'captured');
	assert.equal(result.data, rawData);
});

test('store capture falls back safely when the selected Mii cannot be identified', () => {
	const image = `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}`;
	const harness = storeHarness({ links: [makeLink(otherId, image)] });
	const result = harness.request('mii-studio-fixer:store-capture-request', { id: 'req-3', miiId: selectedId });
	assert.equal(result.status, 'needs-edit');
	assert.equal(result.data, undefined);
});

test('store capture ignores off-site image data even for a matching edit link', () => {
	const image = `https://example.com/miis/image.png?data=${imageData}`;
	const harness = storeHarness({ links: [makeLink(selectedId, image)] });
	const result = harness.request('mii-studio-fixer:store-capture-request', { id: 'req-4', miiId: selectedId });
	assert.equal(result.status, 'needs-edit');
});

test('store capture rejects ambiguous images attached to one Mii link', () => {
	const link = makeLink(selectedId, `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}`);
	const differentData = `${imageData.slice(0, -2)}6e`;
	const otherImage = new FakeNode();
	otherImage.src = `https://studio.mii.nintendo.com/miis/image.png?data=${differentData}`;
	link.images.push(otherImage);
	const harness = storeHarness({ links: [link] });
	const result = harness.request('mii-studio-fixer:store-capture-request', { id: 'req-5', miiId: selectedId });
	assert.equal(result.status, 'needs-edit');
});

test('store capture does not guess a Mii ID from multiple Edit links', () => {
	const image = `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}`;
	const harness = storeHarness({ links: [makeLink(otherId, image), makeLink(selectedId, image)] });
	const result = harness.request('mii-studio-fixer:store-capture-request', { id: 'req-6' });
	assert.equal(result.status, 'needs-edit');
	assert.equal(result.data, undefined);
});

test('store capture reads the selected tile data-src without visiting the editor', () => {
	const image = new FakeNode({ attributes: {
		'data-src': `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}&type=all_body`
	} });
	const tile = new FakeNode({ images: [image], attributes: { 'data-modal': `mii-${selectedId}` } });
	const modal = new FakeNode({ links: [makeLink(selectedId)] });
	const harness = storeHarness({ tiles: [tile], modals: { [`mii-${selectedId}`]: modal } });
	const result = harness.request('mii-studio-fixer:store-capture-request', {
		id: 'tile-1', miiId: selectedId, tileIndex: 0
	});
	assert.equal(result.status, 'captured');
	assert.equal(result.data, rawData);
});

test('store capture refuses data-src when the selected tile opens a different Mii', () => {
	const image = new FakeNode({ attributes: {
		'data-src': `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}`
	} });
	const tile = new FakeNode({ images: [image], attributes: { 'data-modal': `mii-${otherId}` } });
	const harness = storeHarness({ tiles: [tile], modals: { [`mii-${otherId}`]: new FakeNode({ links: [makeLink(otherId)] }) } });
	const result = harness.request('mii-studio-fixer:store-capture-request', {
		id: 'tile-2', miiId: selectedId, tileIndex: 0
	});
	assert.equal(result.status, 'error');
	assert.equal(result.data, undefined);
});

test('store capture refuses ambiguous images on the selected tile', () => {
	const imageA = new FakeNode({ attributes: { 'data-src': `https://studio.mii.nintendo.com/miis/image.png?data=${imageData}` } });
	const imageB = new FakeNode({ attributes: { 'data-src': `https://studio.mii.nintendo.com/miis/image.png?data=${imageData.slice(0, -2)}6e` } });
	const tile = new FakeNode({ images: [imageA, imageB], attributes: { 'data-modal': `mii-${selectedId}` } });
	const harness = storeHarness({ tiles: [tile], modals: { [`mii-${selectedId}`]: new FakeNode({ links: [makeLink(selectedId)] }) } });
	const result = harness.request('mii-studio-fixer:store-capture-request', {
		id: 'tile-3', miiId: selectedId, tileIndex: 0
	});
	assert.equal(result.status, 'error');
	assert.equal(result.data, undefined);
});

test('store capture reads authenticated Edit page data without navigating', async () => {
	const image = new FakeNode({ attributes: { 'data-src': 'https://cdn.nintendo.com/mii-preview.png' } });
	const tile = new FakeNode({ images: [image], attributes: { 'data-modal': `mii-${selectedId}` } });
	const harness = storeHarness({
		tiles: [tile], modals: { [`mii-${selectedId}`]: new FakeNode({ links: [makeLink(selectedId)] }) },
		fetchResponse: async url => ({
		ok: true, url,
		headers: { get(name) { return name === 'content-type' ? 'text/html; charset=utf-8' : null; } },
		async text() { return `<html><body data-page-id="mii-edit" data-params="${imageData}"></body></html>`; }
	}) });
	const result = await harness.requestAsync('mii-studio-fixer:store-capture-request', {
		id: 'fetch-1', miiId: selectedId, tileIndex: 0, editUrl
	});
	assert.equal(result.status, 'captured');
	assert.equal(result.data, rawData);
	assert.equal(harness.fetchCalls.length, 1);
	assert.equal(harness.fetchCalls[0].options.credentials, 'same-origin');
});

test('store capture rejects an Edit URL for another Mii before fetching', async () => {
	const harness = storeHarness();
	const result = await harness.requestAsync('mii-studio-fixer:store-capture-request', {
		id: 'fetch-2', miiId: selectedId,
		editUrl: `https://studio.mii.nintendo.com/miis/${otherId}/edit?client_id=b2486001c0980130`
	});
	assert.equal(result.status, 'error');
	assert.equal(harness.fetchCalls.length, 0);
});

test('store capture falls back to native editor when Edit page has no usable data', async () => {
	const harness = storeHarness({ fetchResponse: async url => ({
		ok: true, url,
		headers: { get() { return 'text/html'; } },
		async text() { return '<html><body data-page-id="mii-edit" data-params="invalid"></body></html>'; }
	}) });
	const result = await harness.requestAsync('mii-studio-fixer:store-capture-request', {
		id: 'fetch-3', miiId: selectedId, editUrl
	});
	assert.equal(result.status, 'needs-edit');
	assert.equal(result.data, undefined);
});

test('store capture ignores authenticated GET redirected to a different page', async () => {
	const harness = storeHarness({ fetchResponse: async () => ({
		ok: true, url: `https://studio.mii.nintendo.com/miis/${otherId}/edit?client_id=b2486001c0980130`,
		headers: { get() { return 'text/html'; } },
		async text() { return `<html><body data-page-id="mii-edit" data-params="${imageData}"></body></html>`; }
	}) });
	const result = await harness.requestAsync('mii-studio-fixer:store-capture-request', {
		id: 'fetch-4', miiId: selectedId, editUrl
	});
	assert.equal(result.status, 'needs-edit');
	assert.equal(result.data, undefined);
});

function openMenu(selectedRecords) {
	const body = new FakeNode();
	const menu = new FakeNode({ parentElement: body, vue: {
		$props: { selectedMii: selectedRecords[0] },
		$data: selectedRecords[1] ? { currentMii: selectedRecords[1] } : {}
	} });
	const controls = ['Edit', 'Erase', 'Close'].map(text => {
		const control = new FakeNode({ parentElement: menu });
		control.textContent = text;
		return control;
	});
	return { body, controls };
}

test('menu ID request identifies the selected Vue Mii and capture reads its data', () => {
	const menu = openMenu([{ id: selectedId, data: rawData }]);
	const harness = storeHarness(menu);
	const menuResult = harness.request('mii-studio-fixer:store-menu-id-request', { id: 'menu-1' });
	assert.equal(menuResult.id, 'menu-1');
	assert.equal(menuResult.miiId, selectedId);
	const captured = harness.request('mii-studio-fixer:store-capture-request', { id: 'capture-1' });
	assert.equal(captured.miiId, selectedId);
	assert.equal(captured.status, 'captured');
	assert.equal(captured.data, rawData);
});

test('menu ID request declines an ambiguous Vue selection', () => {
	const menu = openMenu([
		{ id: selectedId, data: rawData },
		{ id: otherId, data: rawData }
	]);
	const harness = storeHarness(menu);
	const result = harness.request('mii-studio-fixer:store-menu-id-request', { id: 'menu-2' });
	assert.equal(result.miiId, null);
});

test('editor capture saves the current unchanged Mii to its exact-page storage key', () => {
	const calls = [];
	const key = encodeURIComponent(editUrl);
	let harness;
	const current = { name: 'Current' };
	const editor = {
		history: { current },
		onPartsUpdated(value) {
			calls.push(value);
			harness.localStorage.setItem(key, rawData);
		},
		exitEditor() { calls.push('exit'); }
	};
	const canvas = new FakeNode({ vue: editor });
	harness = storeHarness({ canvas, url: editUrl });
	const captured = harness.request('mii-studio-fixer:store-editor-capture-request', { id: 'editor-1' });
	assert.equal(captured.status, 'captured');
	assert.equal(captured.data, rawData);
	assert.strictEqual(calls[0], current);
	const exited = harness.request('mii-studio-fixer:store-exit-request', { id: 'exit-1' });
	assert.equal(exited.status, 'exited');
	assert.deepEqual(calls, [current, 'exit']);
});

test('editor capture refuses to invent data when the editor is absent', () => {
	const harness = storeHarness({ url: editUrl });
	const captured = harness.request('mii-studio-fixer:store-editor-capture-request', { id: 'editor-2' });
	assert.equal(captured.status, 'unavailable');
	assert.equal(captured.data, undefined);
	const exited = harness.request('mii-studio-fixer:store-exit-request', { id: 'exit-2' });
	assert.equal(exited.status, 'error');
});

function restoreHarness({ url = listUrl, bodyText = '', addButton = true, editor = null, previousDraft = null } = {}) {
	const location = new URL(url);
	const draftKey = encodeURIComponent(url);
	const localValues = new Map(previousDraft ? [[draftKey, previousDraft]] : []);
	const sessionValues = new Map();
	const timers = [];
	const button = {
		disabled: false, className: '', id: '', innerText: '+', textContent: '+',
		getClientRects() { return [{}]; },
		getAttribute() { return null; },
		querySelector() { return null; },
		closest() { return null; },
		clicks: 0,
		click() { this.clicks++; }
	};
	const document = Object.assign(events(), {
		body: { innerText: bodyText },
		documentElement: {},
		querySelectorAll(selector) {
			if (selector === 'button, a, [role="button"]') return addButton ? [button] : [];
			if (selector === '*') return editor ? [{ __vue__: editor }] : [];
			return [];
		},
		querySelector(selector) { return selector === 'canvas#canvas' ? null : null; }
	});
	const localStorage = {
		getItem(key) { return localValues.get(key) ?? null; },
		setItem(key, value) { localValues.set(key, value); }
	};
	const sessionStorage = {
		getItem(key) { return sessionValues.get(key) ?? null; },
		setItem(key, value) { sessionValues.set(key, value); },
		removeItem(key) { sessionValues.delete(key); }
	};
	class MutationObserver { constructor(callback) { this.callback = callback; } observe() {} }
	const window = {
		getComputedStyle() { return { display: 'block', visibility: 'visible' }; },
		addEventListener() {}
	};
	vm.runInNewContext(restoreSource, {
		CustomEvent, MutationObserver, URLSearchParams,
		document, window, location, localStorage, sessionStorage,
		setTimeout(callback) { timers.push(callback); },
		console: { warn() {} }
	}, { filename: restorePath });
	return {
		button, document, localStorage, sessionStorage, draftKey,
		capacity() {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-capacity-request', { detail: { id: 'capacity-1' } }));
			return document.emitted.filter(event => event.type === 'mii-studio-fixer:restore-capacity-result').at(-1).detail;
		},
		request(id = 'restore-1', data = rawData) {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-request', { detail: { id, entryId: storedId, data } }));
			return document.emitted.filter(event => event.type === 'mii-studio-fixer:restore-result').at(-1).detail;
		},
		requestImport(id = 'import-1', data = rawData) {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-request', {
				detail: { id, source: 'import', data }
			}));
			return document.emitted.filter(event => event.type === 'mii-studio-fixer:restore-result').at(-1).detail;
		},
		successReceipt() {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-success-request', { detail: { id: 'receipt-1' } }));
			return document.emitted.filter(event => event.type === 'mii-studio-fixer:restore-success-result').at(-1).detail;
		},
		ackSuccess(entryId = storedId, data = rawData) {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-success-ack', { detail: { entryId, data } }));
		},
		async runTimers() {
			for (const callback of timers.splice(0)) callback();
			await new Promise(resolve => setImmediate(resolve));
		},
		results() { return document.emitted.filter(event => event.type === 'mii-studio-fixer:restore-result').map(event => event.detail); }
	};
}

test('restore refuses to click Add when Nintendo says all six slots are occupied', () => {
	const harness = restoreHarness({ bodyText: "So many Mii characters! You'll need to manage them before you can create a new one." });
	assert.equal(harness.capacity().status, 'full');
	assert.equal(harness.request().status, 'full');
	assert.equal(harness.button.clicks, 0);
	assert.equal(harness.sessionStorage.getItem('mii-studio-fixer:pending-restore'), null);
});

test('restore treats an absent Add control as full and leaves saved data untouched', () => {
	const harness = restoreHarness({ addButton: false });
	assert.equal(harness.capacity().status, 'full');
	assert.equal(harness.request().status, 'full');
	assert.equal(harness.sessionStorage.getItem('mii-studio-fixer:pending-restore'), null);
});

test('restore validates data before opening Nintendo new-Mii flow', () => {
	const harness = restoreHarness();
	const result = harness.request('restore-invalid', 'abcd');
	assert.equal(result.status, 'invalid');
	assert.equal(harness.button.clicks, 0);
});

test('restore creates a new Mii using Nintendo editor save methods and clears pending state', async () => {
	const calls = [];
	const editor = {
		miiParams: null,
		editContinue() { calls.push('continue'); },
		onSaveSelected() { calls.push('select-save'); },
		onCheckSubmit() { calls.push('submit'); return Promise.resolve(true); },
		onCreate() {},
		$nextTick() { return Promise.resolve(); }
	};
	const harness = restoreHarness({ editor });
	assert.equal(harness.capacity().status, 'available');
	assert.equal(harness.request().status, 'started');
	assert.equal(harness.button.clicks, 1);
	await harness.runTimers();
	assert.equal(harness.localStorage.getItem(harness.draftKey), rawData);
	assert.deepEqual(calls, ['continue', 'select-save', 'submit']);
	assert.equal(harness.sessionStorage.getItem('mii-studio-fixer:pending-restore'), null);
	assert.equal(harness.results().at(-1).status, 'saved');
	assert.equal(harness.results().at(-1).entryId, storedId);
	assert.equal(harness.successReceipt().entryId, storedId);
	assert.equal(harness.successReceipt().data, rawData);
	harness.ackSuccess('wrong-entry');
	assert.equal(harness.successReceipt().entryId, storedId);
	harness.ackSuccess();
	assert.equal(harness.successReceipt().entryId, undefined);
});

test('native Import saves a new Mii without a stored-entry receipt or removal event', async () => {
	const editor = {
		miiParams: null,
		editContinue() {},
		onSaveSelected() {},
		onCheckSubmit() { return Promise.resolve(true); },
		onCreate() {}
	};
	const harness = restoreHarness({ editor });
	assert.equal(harness.requestImport().status, 'started');
	assert.equal(harness.button.clicks, 1);
	assert.equal(JSON.parse(harness.sessionStorage.getItem('mii-studio-fixer:pending-restore')).source, 'import');
	await harness.runTimers();
	assert.equal(harness.results().at(-1).status, 'saved');
	assert.equal(harness.results().at(-1).entryId, undefined);
	assert.equal(harness.successReceipt().entryId, undefined);
	assert.equal(harness.localStorage.getItem(harness.draftKey), rawData);
});

test('native Import validates Mii data before clicking Add', () => {
	const harness = restoreHarness();
	assert.equal(harness.requestImport('invalid-import', 'abcd').status, 'invalid');
	assert.equal(harness.button.clicks, 0);
});

test('restore protects an existing different draft from being overwritten', async () => {
	const calls = [];
	const editor = {
		miiParams: null,
		editContinue() { calls.push('continue'); },
		onSaveSelected() { calls.push('select-save'); },
		onCheckSubmit() { calls.push('submit'); return Promise.resolve(true); },
		onCreate() {}
	};
	const draft = 'ab'.repeat(46);
	const harness = restoreHarness({ editor, previousDraft: draft });
	assert.equal(harness.request().status, 'started');
	await harness.runTimers();
	assert.equal(harness.localStorage.getItem(harness.draftKey), draft);
	assert.deepEqual(calls, []);
	assert.equal(harness.results().at(-1).status, 'error');
	assert.equal(harness.successReceipt().entryId, undefined);
});

test('restore does not issue a deletion receipt when Nintendo declines the save', async () => {
	const editor = {
		miiParams: null,
		editContinue() {},
		onSaveSelected() {},
		onCheckSubmit() { return Promise.resolve(false); },
		onCreate() {}
	};
	const harness = restoreHarness({ editor });
	assert.equal(harness.request().status, 'started');
	await harness.runTimers();
	assert.equal(harness.results().at(-1).status, 'error');
	assert.equal(harness.successReceipt().entryId, undefined);
});

test('restore waits for Nintendo save confirmation before issuing a deletion receipt', async () => {
	let resolveSave;
	const editor = {
		miiParams: null,
		editContinue() {},
		onSaveSelected() {},
		onCheckSubmit() { return new Promise(resolve => { resolveSave = resolve; }); },
		onCreate() {}
	};
	const harness = restoreHarness({ editor });
	assert.equal(harness.request().status, 'started');
	await harness.runTimers();
	assert.equal(harness.successReceipt().entryId, undefined);
	resolveSave(true);
	await new Promise(resolve => setImmediate(resolve));
	assert.equal(harness.results().at(-1).status, 'saved');
	assert.equal(harness.successReceipt().entryId, storedId);
});
