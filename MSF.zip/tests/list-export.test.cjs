const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');

const source = fs.readFileSync(path.join(__dirname, '..', 'content', 'list-export.js'), 'utf8');
const miijsUrl = pathToFileURL(path.join(__dirname, '..', 'miijs.browser.js')).href;
const rawData = '06042c030c04020f030b020604020c03080000080000000804000a06002f7f040002140313040f0d040407040107';
const formats = ['MNMS', 'CHARINFO', 'NFCD', 'FSDEX', 'PNG_ALL', 'CFCD', 'RCD', 'NCD'];

function harness({ miijs = null } = {}) {
	const downloads = [];
	const blobs = [];
	const state = { requestedUrls: [], errors: [] };
	let document;
	class Element {
		constructor(tagName) {
			this.tagName = tagName.toUpperCase();
			this.children = [];
			this.listeners = new Map();
			this.parentElement = null;
			this.textContent = '';
			this.value = '';
			this.disabled = false;
		}
		append(...children) {
			for (const child of children) {
				child.parentElement = this;
				this.children.push(child);
				if (this.tagName === 'SELECT' && this.children.length === 1) this.value = child.value;
			}
		}
		remove() {
			if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(child => child !== this);
			this.parentElement = null;
		}
		setAttribute(name, value) { this[name] = String(value); }
		addEventListener(type, listener) { this.listeners.set(type, [...(this.listeners.get(type) || []), listener]); }
		focus() { document.activeElement = this; }
		get isConnected() {
			for (let node = this; node; node = node.parentElement) if (node === document.body) return true;
			return false;
		}
		async click() {
			if (this.disabled) return;
			if (this.tagName === 'A') downloads.push({ name: this.download, url: this.href });
			for (const listener of this.listeners.get('click') || []) await listener({ target: this });
		}
	}
	const body = new Element('body');
	document = {
		body, documentElement: body, activeElement: body,
		listeners: new Map(),
		createElement(tagName) { return new Element(tagName); },
		addEventListener(type, listener) { this.listeners.set(type, [...(this.listeners.get(type) || []), listener]); },
		removeEventListener(type, listener) { this.listeners.set(type, (this.listeners.get(type) || []).filter(value => value !== listener)); }
	};
	const url = {
		createObjectURL(blob) { blobs.push(blob); return `blob:test-${blobs.length}`; },
		revokeObjectURL() {}
	};
	const context = {
		URL: url, Blob, Uint8Array, ArrayBuffer, structuredClone, document,
		__importMiijs: () => miijs ? Promise.resolve({ default: miijs }) : import(miijsUrl),
		setTimeout() {},
		chrome: { runtime: { getURL(value) { return value === 'miijs.browser.js' ? miijsUrl : `chrome-extension://test/${value}`; } } },
		fetch: async uri => {
			state.requestedUrls.push(uri);
			return { ok: true, arrayBuffer: async () => Uint8Array.from([9, 8, 7]).buffer };
		},
		console: { error(...args) { state.errors.push(args); } }
	};
	vm.runInNewContext(source.replace("import(chrome.runtime.getURL('miijs.browser.js'))", 'globalThis.__importMiijs()'),
		context, { filename: 'list-export.js' });
	return {
		api: context.MiiStudioFixerExport,
		body, blobs, downloads, state,
		get panel() { return body.children.at(-1)?.children[0]; },
		get select() { return this.panel?.children.find(child => child.tagName === 'SELECT'); },
		get downloadButton() { return this.panel?.children.find(child => child.className === 'mii-studio-fixer-actions')?.children[0]; }
	};
}

test('Export dialog shows the Loader formats and requires a captured Mii', () => {
	const ui = harness();
	assert.throws(() => ui.api.show({ data: 'abc' }), /read this Mii/i);
	ui.api.show({ data: rawData });
	assert.deepEqual(Array.from(ui.select.children, option => option.value), formats);
	assert.equal(ui.select.value, 'MNMS');
});

test('binary downloads use the Loader defaults and seven matching formats', async () => {
	const miijs = (await import(miijsUrl)).default;
	const decoded = await miijs.decodeMii(rawData);
	const expectedMii = structuredClone(decoded);
	expectedMii.meta = {
		...expectedMii.meta,
		creatorMac: '732F6D6E6D73', creatorName: 'Mii Loader',
		name: 'Mii Studio', systemId: '6D69692E746F6F6C'
	};
	const ui = harness();
	for (const format of formats.filter(format => format !== 'PNG_ALL')) {
		ui.api.show({ data: rawData });
		ui.select.value = format;
		await ui.downloadButton.click();
		const blob = ui.blobs.at(-1);
		assert.ok(blob, ui.state.errors.map(error => String(error[1]?.stack || error[1])).join('\n'));
		const actual = new Uint8Array(await blob.arrayBuffer());
		const expected = await miijs.encodeMii(expectedMii, miijs.MiiFormats[format]);
		assert.deepEqual(actual, new Uint8Array(expected), format);
		assert.equal(ui.downloads.at(-1).name, `mii.${format.toLowerCase()}`);
		assert.equal(blob.type, 'application/octet-stream');
	}
});

test('PNG export renders the selected Mii face and preserves the MiiJS QR', async () => {
	const calls = [];
	const stubMiijs = {
		MiiFormats: { FEDEX: 'fedex', EMNMS: 'emnms' },
		async decodeMii(value) { calls.push(['decode', value]); return { meta: {}, faceSeed: value.slice(0, 2) }; },
		async encodeMii(mii, format) {
			calls.push(['encode', format, mii.faceSeed, mii.meta.name]);
			if (format === 'emnms') return Uint8Array.from(mii.faceSeed === '06' ? [0xab, 0xcd] : [0xef, 0x12]);
			return Uint8Array.from([1, 2, 3]);
		},
		async makeQR(bytes, options) {
			calls.push(['qr', [...bytes], options]);
			return Uint8Array.from([137, 80, 78, 71]);
		}
	};
	for (const [data, faceHex] of [[rawData, 'abcd'], [`07${rawData.slice(2)}`, 'ef12']]) {
		const ui = harness({ miijs: stubMiijs });
		ui.api.show({ data });
		ui.select.value = 'PNG_ALL';
		await ui.downloadButton.click();
		assert.deepEqual(ui.state.requestedUrls, [`https://studio.mii.nintendo.com/miis/image.png?data=${faceHex}&type=face&width=512&instanceCount=1`]);
		const qrOptions = calls.at(-1)[2];
		assert.deepEqual(calls.filter(call => call[0] !== 'qr').slice(-3), [
			['decode', data], ['encode', 'fedex', data.slice(0, 2), 'Mii Studio'],
			['encode', 'emnms', data.slice(0, 2), 'Mii Studio']
		]);
		assert.deepEqual(calls.at(-1).slice(0, 2), ['qr', [1, 2, 3]]);
		assert.deepEqual(Object.keys(qrOptions), ['image']);
		assert.deepEqual(Array.from(qrOptions.image), [9, 8, 7]);
		assert.equal(ui.downloads[0].name, 'mii.png');
		assert.equal(ui.blobs[0].type, 'image/png');
		assert.deepEqual(Array.from(new Uint8Array(await ui.blobs[0].arrayBuffer())), [137, 80, 78, 71]);
	}
});
