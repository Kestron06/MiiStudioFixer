const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'content', 'popup-bridge.js'), 'utf8');
const message = { type: 'mii-studio-fixer:popup-page-status' };
const editorUrl = 'https://studio.mii.nintendo.com/miis/0123456789abcdef/edit?client_id=fedcba9876543210&view=editor';
const canonicalEditorUrl = 'https://studio.mii.nintendo.com/miis/0123456789abcdef/edit?client_id=fedcba9876543210';
const hydrateEvent = 'mii-studio-fixer:hydrate-request';

function makeHarness({ pageUrl = editorUrl, stored = {}, onHydrate } = {}) {
	const pageStorage = new Map(Object.entries(stored));
	const events = [];
	const listeners = new Map();
	let messageListener;
	const document = {
		addEventListener(type, listener) {
			const existing = listeners.get(type) ?? [];
			existing.push(listener);
			listeners.set(type, existing);
		},
		removeEventListener(type, listener) {
			listeners.set(type, (listeners.get(type) ?? []).filter(item => item !== listener));
		},
		dispatchEvent(event) {
			events.push(event.type);
			if (event.type === hydrateEvent) onHydrate?.(pageStorage, event);
			for (const listener of listeners.get(event.type) ?? []) listener(event);
			return true;
		}
	};
	const context = vm.createContext({
		URL,
		console,
		document,
		location: { href: pageUrl },
		localStorage: { getItem: key => pageStorage.get(key) ?? null },
		Event: class { constructor(type) { this.type = type; } },
		chrome: { runtime: { onMessage: { addListener(listener) { messageListener = listener; } } } },
		setTimeout: callback => { queueMicrotask(callback); return 1; }
	});
	vm.runInContext(source, context);
	assert.equal(typeof messageListener, 'function', 'bridge must register a runtime message listener');
	return {
		document,
		pageStorage,
		events,
		async send(request = message) {
			return Promise.race([
				new Promise((resolve, reject) => {
					try {
						const result = messageListener(request, {}, resolve);
						if (result && typeof result.then === 'function') result.then(resolve, reject);
						else if (result !== true && result !== undefined) resolve(result);
					} catch (error) { reject(error); }
				}),
				new Promise((_, reject) => setTimeout(() => reject(new Error('bridge did not respond')), 1000))
			]);
		}
	};
}

test('the saved Mii list is ready and unrelated Studio paths are rejected', async () => {
	const list = makeHarness({ pageUrl: 'https://studio.mii.nintendo.com/?client_id=fedcba9876543210' });
	assert.equal((await list.send()).status, 'ready');
	const unrelated = makeHarness({ pageUrl: 'https://studio.mii.nintendo.com/other' });
	assert.equal((await unrelated.send()).status, 'wrong-page');
});

test('a new Mii must be saved once before processing', async () => {
	const h = makeHarness({ pageUrl: 'https://studio.mii.nintendo.com/miis/new' });
	assert.equal((await h.send()).status, 'new');
	assert.equal(h.events.includes(hydrateEvent), false);
});

test('an editor URL without valid Mii and client IDs reports missing-id', async () => {
	for (const pageUrl of [
		'https://studio.mii.nintendo.com/miis/0123456789abcdef/edit',
		'https://studio.mii.nintendo.com/miis/invalid/edit?client_id=fedcba9876543210'
	]) {
		const h = makeHarness({ pageUrl });
		assert.equal((await h.send()).status, 'missing-id');
	}
});

test('an editor with current or canonical Mii data is ready without hydration', async () => {
	for (const key of [encodeURIComponent(editorUrl), encodeURIComponent(canonicalEditorUrl)]) {
		const h = makeHarness({ stored: { [key]: 'encoded-mii' } });
		assert.equal((await h.send()).status, 'ready');
		assert.equal(h.events.includes(hydrateEvent), false);
	}
});

test('the bridge requests MAIN-world hydration when editor data is missing', async () => {
	const h = makeHarness({ onHydrate(storage) {
		storage.set(encodeURIComponent(editorUrl), 'freshly-hydrated-mii');
	} });
	assert.equal((await h.send()).status, 'ready');
	assert.ok(h.events.includes(hydrateEvent));
});

test('the bridge reports missing-data if hydration cannot provide the Mii', async () => {
	const h = makeHarness();
	assert.equal((await h.send()).status, 'missing-data');
	assert.ok(h.events.includes(hydrateEvent));
});

test('the bridge stops retrying once the editor attempted hydration without data', async () => {
	const h = makeHarness({ onHydrate(_storage, _event) {
		h.document.dispatchEvent({ type: 'mii-studio-fixer:hydrate-result', detail: 'no-data' });
	} });
	assert.equal((await h.send()).status, 'missing-data');
	assert.equal(h.events.filter(type => type === hydrateEvent).length, 1);
});
