const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'content', 'list-create.js'), 'utf8');
const origin = 'https://studio.mii.nintendo.com';
const clientId = 'b2486001c0980130';
const oldId = '0123456789abcdef';
const newId = 'fedcba9876543210';
const listUrl = `${origin}/?client_id=${clientId}`;
const newUrl = `${origin}/miis/new?client_id=${clientId}`;
const editUrl = `${origin}/miis/${newId}/edit?client_id=${clientId}`;
const raw = '06042c030c04020f030b020604020c03080000080000000804000a06002f7f040002140313040f0d040407040107';

class CustomEvent {
	constructor(type, options = {}) { this.type = type; this.detail = options.detail; }
}

function pageHtml(pageId, inner = '', attributes = '') {
	return `<html><body data-page-id="${pageId}" ${attributes}>${inner}</body></html>`;
}

function encodedData(value = raw, seed = 0x62) {
	const bytes = Buffer.from(value, 'hex');
	const result = Buffer.alloc(47);
	result[0] = seed;
	for (let index = 0; index < 46; index++) result[index + 1] = ((bytes[index] ^ result[index]) + 7) & 255;
	return result.toString('hex');
}

function attrs(input) {
	const result = new Map();
	for (const match of input.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) {
		result.set(match[1].toLowerCase(), match[2] ?? match[3]);
	}
	return result;
}

class DOMParser {
	parseFromString(html) {
		const body = attrs(/<body\b([^>]*)>/i.exec(html)?.[1] || '');
		const links = [...html.matchAll(/<a\b([^>]*)>/gi)].map(match => attrs(match[1]));
		const metas = [...html.matchAll(/<meta\b([^>]*)>/gi)].map(match => attrs(match[1]));
		return {
			body: {
				dataset: { pageId: body.get('data-page-id') },
				getAttribute(name) { return body.get(name) ?? null; }
			},
			querySelectorAll(selector) {
				if (selector === 'a[href]') return links.filter(link => link.has('href')).map(link => ({
					getAttribute(name) { return link.get(name) ?? null; }
				}));
				const metaName = /^meta\[name="([^"]+)"\]$/.exec(selector)?.[1];
				if (metaName) return metas.filter(meta => meta.get('name') === metaName).map(meta => ({
					getAttribute(name) { return meta.get(name) ?? null; }
				}));
				return [];
			}
		};
	}
}

function response(html, url, status = 200) {
	return {
		ok: status >= 200 && status < 300, status, url,
		headers: { get(name) { return name.toLowerCase() === 'content-type' ? 'text/html; charset=utf-8' : null; } },
		async text() { return html; }
	};
}

function harness({ beforeIds = [oldId], afterIds = [oldId, newId], newPage,
	postStatus = 200, editParams = encodedData(), editPageId = 'mii-edit' } = {}) {
	const listeners = new Map();
	const results = [];
	const requests = [];
	const session = new Map();
	let listFetches = 0;
	const list = ids => pageHtml('mii-list', ids.map(id =>
		`<a href="/miis/${id}/edit?client_id=${clientId}">Edit</a>`).join(''));
	const createPage = newPage ?? pageHtml('mii-new',
		`<meta name="client-id" content="${clientId}"><meta name="csrf-token" content="csrf-value">`);
	const document = {
		addEventListener(type, listener) { listeners.set(type, [...(listeners.get(type) || []), listener]); },
		dispatchEvent(event) {
			if (event.type === 'mii-studio-fixer:restore-create-result') results.push(event.detail);
			for (const listener of listeners.get(event.type) || []) listener(event);
		}
	};
	async function fetch(url, options = {}) {
		requests.push({ url: new URL(url, origin).href, options });
		const requestUrl = new URL(url, origin);
		if (options.method === 'POST') {
			assert.equal(requestUrl.pathname, '/miis/create');
			return response('', requestUrl.href, postStatus);
		}
		if (requestUrl.pathname === '/') return response(list(listFetches++ ? afterIds : beforeIds), requestUrl.href);
		if (requestUrl.pathname === '/miis/new') return response(createPage, requestUrl.href);
		if (requestUrl.pathname === `/miis/${newId}/edit`) return response(
			pageHtml(editPageId, '', `data-params="${editParams}"`), requestUrl.href);
		throw new Error(`Unexpected GET ${requestUrl.href}`);
	}
	vm.runInNewContext(source, {
		CustomEvent, DOMParser, URL, URLSearchParams, Uint8Array, document, fetch,
		location: new URL(listUrl), Date,
		sessionStorage: {
			getItem(key) { return session.get(key) ?? null; },
			setItem(key, value) { session.set(key, value); }
		},
		crypto: { getRandomValues(bytes) { bytes.fill(0x62); return bytes; } }
	});
	return {
		requests, results, session,
		async run(detail = { id: 'request-1', entryId: 'stored-1', data: raw }) {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:restore-create-request', { detail }));
			for (let attempt = 0; attempt < 30 && !results.length; attempt++) {
				await new Promise(resolve => setImmediate(resolve));
			}
			assert.equal(results.length, 1);
			return results[0];
		}
	};
}

test('silent Restore submits encoded Mii and confirms new edit data before success receipt', async () => {
	const page = harness();
	const result = await page.run();
	assert.equal(result.status, 'saved', result.message);
	assert.equal(result.entryId, 'stored-1');
	assert.equal(result.data, raw);
	assert.deepEqual(JSON.parse(page.session.get('mii-studio-fixer:restore-success')).entryId, 'stored-1');
	const post = page.requests.find(request => request.options.method === 'POST');
	assert.ok(post);
	assert.equal(new URL(post.url).pathname, '/miis/create');
	assert.equal(post.options.body.get('csrf_token'), 'csrf-value');
	assert.equal(post.options.body.get('client_id'), clientId);
	assert.equal(post.options.body.get('data'), encodedData(raw));
	for (const request of page.requests) {
		assert.equal(new URL(request.url).origin, origin);
		assert.equal(request.options.credentials, 'include');
	}
});

test('silent Import creates and verifies Mii without a stored-entry success receipt', async () => {
	const page = harness();
	const result = await page.run({ id: 'import-1', source: 'import', data: raw });
	assert.equal(result.status, 'saved', result.message);
	assert.equal(result.source, 'import');
	assert.equal(result.data, raw);
	assert.equal(Object.hasOwn(result, 'entryId'), false);
	assert.equal(page.session.has('mii-studio-fixer:restore-success'), false);
	assert.equal(page.requests.filter(request => request.options.method === 'POST').length, 1);
});

test('silent Import rejects unknown sources before sending requests', async () => {
	const page = harness();
	assert.equal((await page.run({ id: 'bad-source', source: 'other', data: raw })).status, 'unavailable');
	assert.equal(page.requests.length, 0);
});

test('silent Restore does not POST if new-page CSRF metadata is absent', async () => {
	const page = harness({ newPage: pageHtml('mii-new', `<meta name="client-id" content="${clientId}">`) });
	assert.equal((await page.run()).status, 'unavailable');
	assert.equal(page.requests.filter(request => request.options.method === 'POST').length, 0);
});

test('silent Restore does not POST when six Miis are already saved', async () => {
	const ids = Array.from({ length: 6 }, (_, index) => index.toString(16).padStart(16, '0'));
	const page = harness({ beforeIds: ids });
	assert.equal((await page.run()).status, 'unavailable');
	assert.equal(page.requests.filter(request => request.options.method === 'POST').length, 0);
});

test('silent Restore preserves stored copy if creation cannot be verified after POST', async () => {
	const page = harness({ afterIds: [oldId] });
	assert.equal((await page.run()).status, 'uncertain');
	assert.equal(page.session.has('mii-studio-fixer:restore-success'), false);
	assert.equal(page.requests.filter(request => request.options.method === 'POST').length, 1);
});

test('silent Restore preserves stored copy if new edit data differs', async () => {
	const page = harness({ editParams: encodedData('07' + raw.slice(2)) });
	assert.equal((await page.run()).status, 'uncertain');
	assert.equal(page.session.has('mii-studio-fixer:restore-success'), false);
});

test('silent Restore treats a failed POST as uncertain to avoid duplicate creation', async () => {
	const page = harness({ postStatus: 500 });
	assert.equal((await page.run()).status, 'uncertain');
	assert.equal(page.session.has('mii-studio-fixer:restore-success'), false);
});

test('silent Restore does not create another Mii while a prior success receipt remains', async () => {
	const page = harness();
	page.session.set('mii-studio-fixer:restore-success', JSON.stringify({ entryId: 'stored-1', data: raw, at: Date.now() }));
	assert.equal((await page.run()).status, 'uncertain');
	assert.equal(page.requests.filter(request => request.options.method === 'POST').length, 0);
});
