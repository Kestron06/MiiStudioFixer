const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'content', 'list-delete.js'), 'utf8');
const origin = 'https://studio.mii.nintendo.com';
const miiId = '0123456789abcdef';
const otherId = 'fedcba9876543210';
const deleteUrl = `${origin}/miis/${miiId}/delete?client_id=b2486001c0980130`;
const listUrl = `${origin}/?client_id=b2486001c0980130`;

class CustomEvent {
	constructor(type, options = {}) { this.type = type; this.detail = options.detail; }
}

function attributes(html) {
	const result = new Map();
	for (const match of html.matchAll(/([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) {
		result.set(match[1].toLowerCase(), match[2] ?? match[3] ?? match[4] ?? '');
	}
	return result;
}

function element(tag, attributeText, inner = '') {
	const attrs = attributes(attributeText);
	return {
		tagName: tag.toUpperCase(),
		name: attrs.get('name') || '', value: attrs.get('value') || '',
		type: attrs.get('type') || '', disabled: attrs.has('disabled'),
		textContent: inner.replace(/<[^>]*>/g, '').trim(),
		classList: { contains(name) { return (attrs.get('class') || '').split(/\s+/).includes(name); } },
		getAttribute(name) { return attrs.get(name.toLowerCase()) ?? null; },
		hasAttribute(name) { return attrs.has(name.toLowerCase()); }
	};
}

class DOMParser {
	parseFromString(html) {
		const bodyAttrs = attributes(/<body\b([^>]*)>/i.exec(html)?.[1] || '');
		const forms = [...html.matchAll(/<form\b([^>]*)>([\s\S]*?)<\/form>/gi)].map(match => {
			const form = element('form', match[1], match[2]);
			const controls = [...match[2].matchAll(/<input\b([^>]*)>|<button\b([^>]*)>([\s\S]*?)<\/button>/gi)]
				.map(control => control[1] !== undefined
					? element('input', control[1]) : element('button', control[2], control[3]));
			form.action = form.getAttribute('action') || '';
			form.method = form.getAttribute('method') || 'get';
			form.elements = controls;
			form.querySelectorAll = selector => selector.includes('input') || selector.includes('button') ? controls : [];
			form.querySelector = selector => form.querySelectorAll(selector)[0] || null;
			return form;
		});
		const links = [...html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)]
			.map(match => element('a', match[1], match[2]));
		return {
			body: {
				textContent: html.replace(/<[^>]*>/g, ' '),
				dataset: { pageId: bodyAttrs.get('data-page-id') }
			},
			querySelectorAll(selector) {
				if (selector.includes('form')) return forms;
				if (selector.includes('a[href]')) return links.filter(link => link.hasAttribute('href'));
				return [];
			},
			querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
		};
	}
}

class FormData {
	constructor(form) {
		this.fields = [];
		for (const control of form?.elements || []) {
			if (control.name && control.type !== 'submit') this.fields.push([control.name, control.value]);
		}
	}
	append(name, value) { this.fields.push([name, value]); }
	entries() { return this.fields[Symbol.iterator](); }
	[Symbol.iterator]() { return this.entries(); }
	get(name) { return this.fields.find(([key]) => key === name)?.[1] ?? null; }
}

function response(html, url, { status = 200, redirected = false } = {}) {
	return {
		ok: status >= 200 && status < 300, status, url, redirected,
		headers: { get(name) { return name.toLowerCase() === 'content-type' ? 'text/html; charset=utf-8' : null; } },
		async text() { return html; }
	};
}

function harness({ formHtml, postHtml, postUrl = listUrl, postRedirected = true, listHtml } = {}) {
	const listeners = new Map();
	const results = [];
	const requests = [];
	const nativeForm = formHtml ?? `<html><body data-page-id="mii-delete"><form action="/miis/${miiId}/delete" method="post"><input type="hidden" name="csrf_token" value="csrf-token"><input type="hidden" name="client_id" value="b2486001c0980130"><button type="submit">Erase</button></form></body></html>`;
	const deletedList = listHtml ?? '<html><body data-page-id="mii-list"><a href="/miis/aaaaaaaaaaaaaaaa/edit">Other Mii</a></body></html>';
	const document = {
		addEventListener(type, listener) { listeners.set(type, [...(listeners.get(type) || []), listener]); },
		dispatchEvent(event) {
			if (event.type === 'mii-studio-fixer:store-delete-result') results.push(event.detail);
			for (const listener of listeners.get(event.type) || []) listener(event);
		}
	};
	async function fetch(url, options = {}) {
		const request = { url: new URL(url, origin).href, options };
		requests.push(request);
		const method = (options.method || 'GET').toUpperCase();
		if (method === 'POST') return response(postHtml ?? deletedList, postUrl, { redirected: postRedirected });
		if (new URL(request.url).pathname === `/miis/${miiId}/delete`) return response(nativeForm, request.url);
		if (new URL(request.url).pathname === '/') return response(deletedList, request.url);
		throw new Error(`Unexpected request: ${method} ${request.url}`);
	}
	vm.runInNewContext(source, {
		CustomEvent, DOMParser, FormData, URL, URLSearchParams, document, fetch,
		location: new URL(listUrl), console: { warn() {} }
	});
	return {
		requests, results,
		async run(detail = { id: 'request-1', miiId, deleteUrl }) {
			document.dispatchEvent(new CustomEvent('mii-studio-fixer:store-delete-request', { detail }));
			for (let attempt = 0; attempt < 30 && !results.length; attempt++) {
				await new Promise(resolve => setImmediate(resolve));
			}
			assert.equal(results.length, 1, 'bridge must report one result');
			assert.equal(results[0].id, detail.id);
			return results[0];
		}
	};
}

test('silent Store delete submits native CSRF form and confirms saved-list absence', async () => {
	const page = harness();
	const result = await page.run();
	assert.equal(result.status, 'deleted', result.message);
	assert.equal(page.requests[0].url, deleteUrl);
	const post = page.requests.find(request => request.options.method?.toUpperCase() === 'POST');
	assert.ok(post, 'native delete form should be submitted');
	assert.equal(new URL(post.url).pathname, `/miis/${miiId}/delete`);
	const body = typeof post.options.body === 'string'
		? new URLSearchParams(post.options.body) : post.options.body;
	assert.equal(body?.get('csrf_token'), 'csrf-token');
	assert.equal(body?.get('client_id'), 'b2486001c0980130');
	for (const request of page.requests) {
		assert.ok(['same-origin', 'include'].includes(request.options.credentials), 'authenticated requests need credentials');
		assert.equal(new URL(request.url).origin, origin);
	}
});

test('silent Store delete rejects a URL for another Mii before any request', async () => {
	const page = harness();
	const result = await page.run({ id: 'request-1', miiId, deleteUrl: `${origin}/miis/${otherId}/delete` });
	assert.notEqual(result.status, 'deleted');
	assert.equal(page.requests.length, 0);
});

test('silent Store delete rejects a foreign delete URL before any request', async () => {
	const page = harness();
	const result = await page.run({ id: 'request-1', miiId, deleteUrl: `https://example.com/miis/${miiId}/delete` });
	assert.notEqual(result.status, 'deleted');
	assert.equal(page.requests.length, 0);
});

test('silent Store delete never posts a missing native confirmation form', async () => {
	const page = harness({ formHtml: '<html><body>Sign in required</body></html>' });
	const result = await page.run();
	assert.notEqual(result.status, 'deleted');
	assert.equal(page.requests.filter(request => request.options.method?.toUpperCase() === 'POST').length, 0);
});

test('silent Store delete never guesses between duplicate native confirmation forms', async () => {
	const form = `<form action="/miis/${miiId}/delete" method="post"><input type="hidden" name="_csrf" value="token"><button type="submit">Erase</button></form>`;
	const page = harness({ formHtml: `<body data-page-id="mii-delete">${form}${form}</body>` });
	const result = await page.run();
	assert.notEqual(result.status, 'deleted');
	assert.equal(page.requests.filter(request => request.options.method?.toUpperCase() === 'POST').length, 0);
});

test('silent Store delete rejects a form that would post another Mii ID', async () => {
	const page = harness({ formHtml: `<body data-page-id="mii-delete"><form action="/miis/${otherId}/delete" method="post"><button type="submit">Erase</button></form></body>` });
	const result = await page.run();
	assert.equal(result.status, 'unavailable');
	assert.equal(page.requests.filter(request => request.options.method?.toUpperCase() === 'POST').length, 0);
});

test('a successful POST that still shows the Mii is uncertain, not deleted', async () => {
	const presentList = `<html><body data-page-id="mii-list"><a href="/miis/${miiId}/edit">Still saved</a></body></html>`;
	const page = harness({ postHtml: presentList, listHtml: presentList });
	const result = await page.run();
	assert.equal(result.status, 'uncertain', result.message);
	assert.equal(page.requests.filter(request => request.options.method?.toUpperCase() === 'POST').length, 1);
});

test('a POST followed by an unverified list is uncertain, not deleted', async () => {
	const page = harness({ listHtml: '<html><body>Sign in required</body></html>' });
	const result = await page.run();
	assert.equal(result.status, 'uncertain');
	assert.equal(page.requests.filter(request => request.options.method?.toUpperCase() === 'POST').length, 1);
});
