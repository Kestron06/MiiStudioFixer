const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'content', 'list-import.js'), 'utf8')
	.replace("import(chrome.runtime.getURL('miijs.browser.js'))", 'Promise.resolve({ default: miijsStub })');
const raw = '06042c030c04020f030b020604020c03080000080000000804000a06002f7f040002140313040f0d040407040107';

class CustomEvent {
	constructor(type, options = {}) { this.type = type; this.detail = options.detail; }
}

function harness(miijs = {}) {
	const listeners = new Map();
	const results = [];
	const inputs = [];
	const document = {
		body: { append(input) { inputs.push(input); } },
		addEventListener(type, listener) { listeners.set(type, [...(listeners.get(type) || []), listener]); },
		dispatchEvent(event) {
			if (event.type === 'mii-studio-fixer:import-file-result') results.push(event.detail);
			for (const listener of listeners.get(event.type) || []) listener(event);
		},
		createElement(tag) {
			assert.equal(tag, 'input');
			const handlers = new Map();
			return {
				files: [], clicked: false, removed: false,
				addEventListener(type, listener) { handlers.set(type, listener); },
				click() { this.clicked = true; },
				remove() { this.removed = true; },
				fire(type) { return handlers.get(type)?.(); }
			};
		}
	};
	vm.runInNewContext(source, { document, CustomEvent, miijsStub: miijs, Uint8Array, TextDecoder, atob, chrome: {}, console });
	return { document, inputs, results, async run(file) {
		document.dispatchEvent(new CustomEvent('mii-studio-fixer:import-file-request', { detail: { id: 'request-1' } }));
		const input = inputs.at(-1);
		assert.ok(input.clicked, 'file picker opens synchronously');
		assert.equal(input.accept, undefined, 'file picker allows every extension');
		if (file === null) input.fire('cancel');
		else { input.files = [file]; await input.fire('change'); }
		assert.ok(input.removed);
		assert.equal(results.length, 1);
		return results[0];
	} };
}

test('Import reads Mii Studio hex text with an arbitrary extension', async () => {
	const page = harness();
	const result = await page.run({ name: 'mii.custom', type: 'application/octet-stream',
		async arrayBuffer() { return Uint8Array.from(Buffer.from(`${raw.slice(0, 46)}\n${raw.slice(46)}`)).buffer; } });
	assert.equal(result.status, 'ready', result.message);
	assert.equal(result.data, raw);
	assert.equal(result.fileName, 'mii.custom');
});

test('Import converts MiiJS-supported binary under an arbitrary extension', async () => {
	let decoded;
	const page = harness({ MiiFormats: { MNMS: 'mnms' },
		async decodeMii(bytes) { decoded = [...bytes]; return { test: true }; },
		async encodeMii(mii, format) {
			assert.equal(mii.test, true);
			assert.equal(format, 'mnms');
			return Uint8Array.from(Buffer.from(raw, 'hex'));
		}
	});
	const result = await page.run({ name: 'mii.whatever', type: 'application/octet-stream',
		async arrayBuffer() { return Uint8Array.from([1, 2, 3]).buffer; } });
	assert.equal(result.status, 'ready', result.message);
	assert.deepEqual(decoded, [1, 2, 3]);
	assert.equal(result.data, raw);
});

test('Import scans QR images identified by bytes even with an arbitrary extension and MIME type', async () => {
	let scanned = false;
	const page = harness({ MiiFormats: { MNMS: 'mnms' },
		async scanQR(bytes) { assert.deepEqual([...bytes.slice(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]); scanned = true; return Uint8Array.from([4]); },
		async decodeMii(bytes) { assert.deepEqual([...bytes], [4]); return {}; },
		async encodeMii() { return Uint8Array.from(Buffer.from(raw, 'hex')); }
	});
	const result = await page.run({ name: 'mii.unknown', type: 'application/octet-stream',
		async arrayBuffer() { return Uint8Array.from([137, 80, 78, 71, 13, 10, 26, 10, 1]).buffer; } });
	assert.equal(result.status, 'ready', result.message);
	assert.equal(scanned, true);
});

test('Import decodes base64 Mii Studio data with an arbitrary extension', async () => {
	const page = harness();
	const result = await page.run({ name: 'mii.dat',
		async arrayBuffer() { return Uint8Array.from(Buffer.from(Buffer.from(raw, 'hex').toString('base64'))).buffer; } });
	assert.equal(result.status, 'ready', result.message);
	assert.equal(result.data, raw);
});

test('Import tries QR scanning when MiiJS cannot decode unknown image bytes directly', async () => {
	let decodeCalls = 0;
	let scanned = false;
	const page = harness({ MiiFormats: { MNMS: 'mnms' },
		async decodeMii(bytes) {
			decodeCalls++;
			if (decodeCalls === 1) {
				assert.deepEqual([...bytes.slice(0, 6)], [...Buffer.from('GIF89a')]);
				throw new Error('Unknown format');
			}
			assert.deepEqual([...bytes], [4]);
			return {};
		},
		async scanQR(bytes) { scanned = true; assert.equal(bytes[0], 71); return Uint8Array.from([4]); },
		async encodeMii() { return Uint8Array.from(Buffer.from(raw, 'hex')); }
	});
	const result = await page.run({ name: 'qr.mystery', type: 'application/octet-stream',
		async arrayBuffer() { return Uint8Array.from([...Buffer.from('GIF89a'), 1, 0, 1, 0, 0, 0]).buffer; } });
	assert.equal(result.status, 'ready', result.message);
	assert.equal(scanned, true);
	assert.equal(decodeCalls, 2);
});

test('Import reports cancel and invalid data without Mii Studio creation', async () => {
	const cancelled = harness();
	assert.equal((await cancelled.run(null)).status, 'cancelled');
	const invalid = harness({ async decodeMii() { throw new Error('Unsupported Mii data'); }, async scanQR() { return null; } });
	const result = await invalid.run({ name: 'bad.random',
		async arrayBuffer() { return Uint8Array.from(Buffer.from('not a Mii')).buffer; } });
	assert.equal(result.status, 'error');
	assert.match(result.message, /Could not decode.*Mii QR code/);
});
