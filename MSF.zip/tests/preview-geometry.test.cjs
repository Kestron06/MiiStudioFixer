const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const sourcePath = path.join(__dirname, '..', 'content', 'preview.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const overlayCss = fs.readFileSync(path.join(__dirname, '..', 'content', 'preview.css'), 'utf8');
const closingIife = '})();';
assert.ok(source.trimEnd().endsWith(closingIife), 'preview script should end in an IIFE');

// Exercise the shipped content script without exporting implementation details to the page.
const instrumentedSource = `${source.slice(0, source.lastIndexOf(closingIife))}
	globalThis.__previewGeometry = {
		beginInteraction, constrainRect, endInteraction, flushLayoutSave,
		getSnapEdges, getViewportBounds, layoutFromRect, normalizeStoredLayout,
		onInteractionEnd, onInteractionMove, onOverlayKeydown,
		rectFromLayout, resizeRect, snapRect
	};
${closingIife}`;

function createHarness({ width = 800, height = 600 } = {}) {
	let timerId = 0;
	const frames = new Map();
	const timers = new Map();
	const window = {
		innerWidth: width,
		innerHeight: height,
		addEventListener() {}
	};
	const document = {
		documentElement: { clientWidth: width, clientHeight: height },
		addEventListener() {}
	};
	const writes = [];
	const chrome = {
		storage: {
			onChanged: { addListener() {} },
			local: {
				get: async () => ({}),
				set: async value => { writes.push(value); }
			}
		}
	};
	const context = {
		chrome,
		console,
		document,
		window,
		setTimeout: callback => {
			const id = ++timerId;
			timers.set(id, callback);
			return id;
		},
		clearTimeout: id => timers.delete(id),
		setInterval: () => ++timerId,
		clearInterval() {},
		requestAnimationFrame: callback => {
			const id = ++timerId;
			frames.set(id, callback);
			return id;
		},
		cancelAnimationFrame: id => frames.delete(id)
	};

	vm.runInNewContext(instrumentedSource, context, { filename: sourcePath });
	return {
		geometry: context.__previewGeometry, window, document, writes,
		pendingFrames: () => frames.size,
		runFrames: () => {
			const callbacks = [...frames.values()];
			frames.clear();
			callbacks.forEach(callback => callback());
		},
		runTimers: () => {
			const callbacks = [...timers.values()];
			timers.clear();
			callbacks.forEach(callback => callback());
		}
	};
}

function plain(value) {
	return JSON.parse(JSON.stringify(value));
}

const bounds = { left: 16, top: 16, right: 784, bottom: 584 };
const start = { x: 300, y: 200, width: 150, height: 140 };

function fakeOverlay(rect = start) {
	const attributes = new Map();
	const style = new Map();
	const captured = new Set();
	let overlay;
	const host = {
		isConnected: true,
		focusCalls: 0,
		style: { setProperty: (key, value) => style.set(key, value) },
		focus() { this.focusCalls++; },
		removeAttribute: key => attributes.delete(key),
		setAttribute: (key, value) => attributes.set(key, value),
		getBoundingClientRect: () => ({
			left: overlay.rect.x, top: overlay.rect.y,
			width: overlay.rect.width, height: overlay.rect.height
		})
	};
	const source = {
		setPointerCapture: id => captured.add(id),
		hasPointerCapture: id => captured.has(id),
		releasePointerCapture: id => captured.delete(id)
	};
	overlay = {
		host, bounds, rect: { ...rect },
		announcement: { textContent: '' },
		interaction: null,
		settleTimer: null
	};
	return { attributes, captured, source, style, overlay };
}

function pointerEvent(source, pointerId, clientX, clientY, overrides = {}) {
	let cancelled = 0;
	const event = {
		currentTarget: source, pointerId, clientX, clientY,
		isPrimary: true, button: 0,
		preventDefault() { cancelled++; },
		stopPropagation() { cancelled++; },
		...overrides
	};
	return { event, cancelled: () => cancelled };
}

test('all eight edge and corner handles resize only their selected sides', async t => {
	const { geometry } = createHarness();
	const expected = {
		n: { x: 300, y: 160, width: 150, height: 180 },
		ne: { x: 300, y: 160, width: 190, height: 180 },
		e: { x: 300, y: 200, width: 190, height: 140 },
		se: { x: 300, y: 200, width: 190, height: 180 },
		s: { x: 300, y: 200, width: 150, height: 180 },
		sw: { x: 260, y: 200, width: 190, height: 180 },
		w: { x: 260, y: 200, width: 190, height: 140 },
		nw: { x: 260, y: 160, width: 190, height: 180 }
	};

	for (const [direction, result] of Object.entries(expected)) {
		await t.test(direction, () => {
			const dx = direction.includes('w') ? -40 : 40;
			const dy = direction.includes('n') ? -40 : 40;
			assert.deepEqual(plain(geometry.resizeRect(start, direction, dx, dy, bounds)), result);
		});
	}
});

test('moving snaps at the threshold, not one pixel outside it', () => {
	const { geometry } = createHarness();
	const rect = { x: 44, y: 200, width: 120, height: 120 };
	assert.equal(geometry.snapRect(rect, bounds).x, 16);
	assert.equal(geometry.snapRect({ ...rect, x: 45 }, bounds).x, 45);
	assert.equal(geometry.snapRect({ ...rect, x: 635 }, bounds).x, 635);
	assert.equal(geometry.snapRect({ ...rect, x: 636 }, bounds).x, 664);
	assert.equal(geometry.snapRect({ ...rect, x: 660 }, bounds, 'move', '', -4).x, 664,
		'pointer release near an edge snaps even after a small inward movement');
});

test('moving and resizing can snap to both edges of a corner', () => {
	const { geometry } = createHarness();
	const rect = { x: 44, y: 44, width: 120, height: 120 };
	assert.deepEqual(plain(geometry.snapRect(rect, bounds)), {
		x: 16, y: 16, width: 120, height: 120
	});
	assert.deepEqual(plain(geometry.snapRect(rect, bounds, 'resize', 'nw', -1, -1)), {
		x: 16, y: 16, width: 148, height: 148
	});
	assert.deepEqual(plain(geometry.getSnapEdges({ x: 16, y: 16, width: 148, height: 148 }, bounds)), {
		snapX: 'left', snapY: 'top'
	});
});

test('resizing respects minimum, maximum and viewport limits', () => {
	const { geometry } = createHarness();
	assert.equal(geometry.resizeRect(start, 'e', -1000, 0, bounds).width, 96);
	assert.equal(geometry.resizeRect(start, 'w', 1000, 0, bounds).width, 96);
	assert.equal(geometry.resizeRect(start, 's', 0, -1000, bounds).height, 96);
	assert.equal(geometry.resizeRect(start, 'n', 0, 1000, bounds).height, 96);
	assert.equal(geometry.resizeRect(start, 'e', 1000, 0, bounds).width, 484);
	assert.equal(geometry.resizeRect(start, 's', 0, 1000, bounds).height, 384);
	assert.equal(geometry.resizeRect({ x: 180, y: 80, width: 150, height: 140 }, 'e', 1000, 0, bounds).width, 512);
});

test('tiny visual viewports still produce an on-screen, positive-size preview', () => {
	const { geometry, window } = createHarness();
	window.visualViewport = { offsetLeft: 3, offsetTop: 7, width: 24, height: 20 };
	const tinyBounds = geometry.getViewportBounds();
	const rect = geometry.rectFromLayout(null, tinyBounds);
	assert.equal(tinyBounds.right - tinyBounds.left, 1);
	assert.equal(tinyBounds.bottom - tinyBounds.top, 1);
	assert.deepEqual(plain(rect), {
		x: tinyBounds.left, y: tinyBounds.top, width: 1, height: 1
	});
	assert.deepEqual(plain(geometry.constrainRect({ x: -100, y: -100, width: 512, height: 512 }, tinyBounds)), plain(rect));
});

test('saved free positions round-trip, and snapped edges survive viewport changes', () => {
	const { geometry } = createHarness();
	const free = { x: 201.25, y: 177.5, width: 175, height: 143 };
	const saved = geometry.normalizeStoredLayout(geometry.layoutFromRect(free, bounds));
	const restored = geometry.rectFromLayout(saved, bounds);
	for (const key of ['x', 'y', 'width', 'height']) {
		assert.ok(Math.abs(restored[key] - free[key]) < 0.000001, key);
	}
	const snapped = geometry.layoutFromRect({ x: 640, y: 16, width: 144, height: 144 }, bounds);
	assert.deepEqual([snapped.snapX, snapped.snapY], ['right', 'top']);
	assert.deepEqual(plain(geometry.rectFromLayout(snapped, { left: 20, top: 25, right: 620, bottom: 425 })), {
		x: 476, y: 25, width: 144, height: 144
	});
	assert.equal(geometry.normalizeStoredLayout({ v: 2, width: 144, height: 144, xRatio: 1, yRatio: 1 }), null);
});

test('keyboard arrows detach from an edge and Shift changes size', () => {
	const { geometry } = createHarness();
	const attributes = new Map();
	const host = {
		isConnected: true,
		style: { setProperty() {} },
		removeAttribute: key => attributes.delete(key),
		setAttribute: (key, value) => attributes.set(key, value),
		getBoundingClientRect: () => ({})
	};
	const overlay = {
		host,
		bounds,
		rect: { x: 16, y: 200, width: 120, height: 120 },
		announcement: { textContent: '' },
		interaction: null,
		settleTimer: null
	};
	const key = (name, shiftKey = false) => ({
		key: name, shiftKey, altKey: false, ctrlKey: false, metaKey: false,
		preventDefault() {}, stopPropagation() {}
	});
	geometry.onOverlayKeydown(overlay, key('ArrowRight'));
	assert.equal(overlay.rect.x, 24, 'moving away from left edge should not re-snap');
	geometry.onOverlayKeydown(overlay, key('ArrowLeft'));
	assert.equal(overlay.rect.x, 16);
	geometry.onOverlayKeydown(overlay, key('ArrowRight', true));
	assert.equal(overlay.rect.width, 128);
	geometry.onOverlayKeydown(overlay, key('ArrowLeft', true));
	assert.equal(overlay.rect.width, 120);
});

test('pointer capture, RAF batching, release snap and layout save', async () => {
	const harness = createHarness();
	const { geometry } = harness;
	const { overlay, source, captured, attributes, style } = fakeOverlay();
	const down = pointerEvent(source, 7, 100, 100);
	geometry.beginInteraction(overlay, down.event, 'move');
	assert.equal(down.cancelled(), 2);
	assert.deepEqual([...captured], [7]);
	assert.equal(attributes.get('data-interaction'), 'move');
	assert.equal(overlay.host.focusCalls, 1);

	const firstMove = pointerEvent(source, 7, 110, 115);
	const secondMove = pointerEvent(source, 7, 130, 130);
	geometry.onInteractionMove(overlay, firstMove.event);
	geometry.onInteractionMove(overlay, secondMove.event);
	assert.equal(harness.pendingFrames(), 1, 'multiple moves should share a frame');
	assert.deepEqual(plain(overlay.rect), start, 'layout should not change before the frame');
	harness.runFrames();
	assert.deepEqual(plain(overlay.rect), { x: 330, y: 230, width: 150, height: 140 });
	assert.equal(style.get('--preview-x'), '330px');

	geometry.onInteractionMove(overlay, pointerEvent(source, 7, 400, 314).event);
	assert.equal(harness.pendingFrames(), 1);
	const up = pointerEvent(source, 7, 410, 324);
	geometry.onInteractionEnd(overlay, up.event);
	assert.equal(up.cancelled(), 2);
	assert.equal(harness.pendingFrames(), 0, 'pointerup should cancel any queued move');
	assert.equal(overlay.interaction, null);
	assert.equal(captured.size, 0);
	assert.equal(attributes.has('data-interaction'), false);
	assert.deepEqual(plain(overlay.rect), { x: 634, y: 444, width: 150, height: 140 });
	assert.match(overlay.announcement.textContent, /snapped to right and bottom/);

	geometry.flushLayoutSave();
	await new Promise(resolve => setImmediate(resolve));
	assert.equal(harness.writes.length, 1);
	const saved = harness.writes[0]['mii-studio-mii-loader-preview-layout-v1'];
	assert.deepEqual(plain([saved.snapX, saved.snapY]), ['right', 'bottom']);
	assert.deepEqual(plain(geometry.rectFromLayout(saved, bounds)), plain(overlay.rect));
});

test('only one primary left-button pointer can interact, and cancel restores start', () => {
	const harness = createHarness();
	const { geometry } = harness;
	const { overlay, source, captured, attributes } = fakeOverlay();
	geometry.beginInteraction(overlay, pointerEvent(source, 1, 100, 100, { isPrimary: false }).event, 'move');
	geometry.beginInteraction(overlay, pointerEvent(source, 1, 100, 100, { button: 2 }).event, 'move');
	assert.equal(overlay.interaction, null);
	assert.equal(captured.size, 0);

	const failingSource = { setPointerCapture() { throw new Error('unavailable'); } };
	geometry.beginInteraction(overlay, pointerEvent(failingSource, 1, 100, 100).event, 'move');
	assert.equal(overlay.interaction, null);
	geometry.beginInteraction(overlay, pointerEvent(source, 1, 100, 100).event, 'move');
	geometry.beginInteraction(overlay, pointerEvent(source, 2, 100, 100).event, 'resize', 'nw');
	assert.equal(overlay.interaction.pointerId, 1);
	assert.deepEqual([...captured], [1]);
	geometry.onInteractionMove(overlay, pointerEvent(source, 2, 500, 500).event);
	geometry.onInteractionEnd(overlay, pointerEvent(source, 2, 500, 500).event);
	assert.equal(harness.pendingFrames(), 0);
	assert.equal(overlay.interaction.pointerId, 1);

	geometry.onInteractionMove(overlay, pointerEvent(source, 1, 150, 150).event);
	harness.runFrames();
	assert.deepEqual(plain(overlay.rect), { x: 350, y: 250, width: 150, height: 140 });
	geometry.endInteraction(overlay, { commit: false, animate: false });
	assert.equal(overlay.interaction, null);
	assert.equal(captured.size, 0);
	assert.equal(attributes.has('data-interaction'), false);
	assert.deepEqual(plain(overlay.rect), start);
	harness.runTimers();
	assert.equal(harness.writes.length, 0, 'cancellation should not persist a layout');
});

test('grabbing during a settle animation starts from the visible rectangle', () => {
	const harness = createHarness();
	const { overlay, source } = fakeOverlay();
	overlay.host.getBoundingClientRect = () => ({ left: 280, top: 190, width: 145, height: 135 });
	harness.geometry.beginInteraction(overlay, pointerEvent(source, 5, 100, 100).event, 'move');
	assert.deepEqual(plain(overlay.interaction.startRect), {
		x: 280, y: 190, width: 145, height: 135
	});
	harness.geometry.onInteractionMove(overlay, pointerEvent(source, 5, 110, 120).event);
	harness.runFrames();
	assert.deepEqual(plain(overlay.rect), { x: 290, y: 210, width: 145, height: 135 });
	harness.geometry.endInteraction(overlay, { commit: false, animate: false });
	assert.deepEqual(plain(overlay.rect), { x: 280, y: 190, width: 145, height: 135 });
});

test('interaction CSS has eight handles, pointer input and reduced-motion rules', () => {
	for (const direction of ['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw']) {
		assert.ok(source.includes(`.resize-handle[data-resize="${direction}"]`), `${direction} handle`);
	}
	assert.match(overlayCss, /pointer-events:\s*auto\s*!important/);
	assert.match(overlayCss, /touch-action:\s*none\s*!important/);
	assert.match(overlayCss, /\[data-interaction\]\s*\{\s*transition:\s*none\s*!important/s);
	assert.match(overlayCss, /@media\s*\(prefers-reduced-motion:\s*reduce\)/);
	assert.match(source, /@media\s*\(prefers-reduced-motion:\s*reduce\)/);
});
