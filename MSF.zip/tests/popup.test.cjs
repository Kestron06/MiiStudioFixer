const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'popup', 'popup.js'), 'utf8')
	.replace(/loadMode\(\);\s*loadStoredMiis\(\);\s*checkCurrentPage\(\);\s*$/,
		'globalThis.testAPI = { loadMode, loadStoredMiis, checkCurrentPage, renderStoredMiis };');
const modeKey = 'mii-studio-fixer-preview-mode';
const oldKey = 'mii-studio-mii-loader-preview-enabled';
const storedKey = 'mii-studio-fixer-stored-miis-v1';

class Element {
	constructor() {
		this.children = [];
		this.events = {};
		this.attributes = {};
		this.hidden = false;
		this.disabled = false;
		this.textContent = '';
	}
	addEventListener(event, callback) { this.events[event] = callback; }
	setAttribute(name, value) { this.attributes[name] = value; }
	append(...children) { this.children.push(...children); }
	appendChild(child) { this.children.push(child); }
	replaceChildren(...children) { this.children = children; }
	showModal() { this.open = true; }
	close() { this.open = false; this.events.close?.(); }
	focus() { this.focused = true; }
}

function makeHarness({ pageStatus = 'ready', settings = {}, storedMiis,
	failGet = false, failSet = false, failMessage = false, tabPresent = true } = {}) {
	const inputs = ['floating', 'replace', 'off'].map(value => ({ name: 'preview-mode', value, checked: false }));
	const options = new Element();
	options.disabled = true;
	options.addEventListener = function(event, callback) { this[event] = callback; };
	const warning = { hidden: true, textContent: '', innerHTML: '' };
	const storedList = new Element();
	const storedEmpty = new Element();
	const storedStatus = new Element();
	const deleteDialog = new Element();
	const deleteMessage = new Element();
	const deleteError = new Element();
	const deleteCancel = new Element();
	const deleteConfirm = new Element();
	const elements = {
		'preview-options': options, 'page-warning': warning,
		'stored-list': storedList, 'stored-empty': storedEmpty, 'stored-status': storedStatus,
		'delete-confirmation': deleteDialog, 'delete-confirmation-message': deleteMessage,
		'delete-error': deleteError, 'delete-cancel': deleteCancel, 'delete-confirm': deleteConfirm
	};
	const document = {
		getElementById: id => elements[id],
		createElement: () => new Element(),
		querySelectorAll() { return inputs; }
	};
	const stored = new Map(Object.entries(settings));
	if (storedMiis !== undefined) stored.set(storedKey, storedMiis);
	const writes = [];
	const sentMessages = [];
	let storageChangeListener;
	let rejectGet = failGet;
	let rejectSet = failSet;
	const context = vm.createContext({
		console,
		document,
		chrome: {
			storage: { onChanged: { addListener: callback => { storageChangeListener = callback; } }, local: {
				get: async () => {
					if (rejectGet) throw new Error('storage read failed');
					return Object.fromEntries(stored);
				},
				set: async value => {
					if (rejectSet) throw new Error('storage write failed');
					writes.push(value);
					for (const [key, item] of Object.entries(value)) {
						const oldValue = stored.get(key);
						stored.set(key, item);
						storageChangeListener?.({ [key]: { oldValue, newValue: item } }, 'local');
					}
				}
			} },
			tabs: {
				query: async () => tabPresent ? [{ id: 7 }] : [],
				sendMessage: async (tabId, message) => {
					sentMessages.push({ tabId, message });
					if (failMessage) throw new Error('Receiving end does not exist.');
					return { status: pageStatus };
				}
			}
		}
	});
	vm.runInContext(source, context);
	return { api: context.testAPI, inputs, options, warning, stored,
		writes, sentMessages, storedList, storedEmpty, storedStatus, deleteDialog, deleteMessage,
		deleteError, deleteCancel, deleteConfirm,
		setFailGet: value => { rejectGet = value; }, setFailSet: value => { rejectSet = value; },
		changeStorage: entries => storageChangeListener?.({ [storedKey]: { newValue: entries } }, 'local') };
}

test('migrates an enabled legacy setting to floating preview', async () => {
	const h = makeHarness({ settings: { [oldKey]: true } });
	await h.api.loadMode();
	assert.equal(h.stored.get(modeKey), 'floating');
	assert.equal(h.inputs[0].checked, true);
	assert.equal(h.options.disabled, false);
});

test('a saved mode takes precedence and can change to replacement', async () => {
	const h = makeHarness({ settings: { [modeKey]: 'off', [oldKey]: true } });
	await h.api.loadMode();
	assert.equal(h.inputs[2].checked, true);
	await h.options.change({ target: h.inputs[1] });
	assert.equal(h.stored.get(modeKey), 'replace');
	assert.equal(h.inputs[1].checked, true);
});

test('wrong page and missing URL IDs use the Loader wording', async () => {
	const wrong = makeHarness({ failMessage: true });
	await wrong.api.checkCurrentPage();
	assert.match(wrong.warning.innerHTML, /Please visit .*the Mii Studio.*then edit a Mii to continue\./);
	const explicitWrong = makeHarness({ pageStatus: 'wrong-page' });
	await explicitWrong.api.checkCurrentPage();
	assert.match(explicitWrong.warning.innerHTML, /Please visit .*the Mii Studio/);
	const missing = makeHarness({ pageStatus: 'missing-id' });
	await missing.api.checkCurrentPage();
	assert.equal(missing.warning.textContent,
		'Could not find Mii ID and/or client ID in the URL. Close and revisit the page and try again.');
});

test('an absent active tab shows the wrong-page warning without messaging', async () => {
	const h = makeHarness({ tabPresent: false });
	await h.api.checkCurrentPage();
	assert.match(h.warning.innerHTML, /Please visit .*the Mii Studio/);
	assert.equal(h.sentMessages.length, 0);
});

test('new Mii page asks for the first save before processing', async () => {
	const h = makeHarness({ pageStatus: 'new' });
	await h.api.checkCurrentPage();
	assert.equal(h.warning.textContent, 'The Mii must be saved once before we can process it.');
	assert.equal(h.warning.hidden, false);
	assert.equal(h.sentMessages.length, 1);
});

test('popup checks the active tab through messaging without its URL or scripting API', async () => {
	const h = makeHarness();
	await h.api.checkCurrentPage();
	assert.equal(h.warning.hidden, true);
	assert.equal(h.sentMessages.length, 1);
	assert.equal(h.sentMessages[0].tabId, 7);
	assert.equal(h.sentMessages[0].message.type, 'mii-studio-fixer:popup-page-status');
});

test('missing data after recovery uses the Loader wording', async () => {
	const h = makeHarness({ pageStatus: 'missing-data' });
	await h.api.checkCurrentPage();
	assert.equal(h.warning.textContent,
		'Could not load the current Mii from the editor. Wait for the editor to finish loading, then reopen this popup.');
});

test('a bridge error displays the popup initialization warning', async () => {
	const h = makeHarness({ pageStatus: 'error' });
	await h.api.checkCurrentPage();
	assert.equal(h.warning.textContent,
		'The popup failed to initialize. Check the popup console for details and try again.');
});

test('the saved Mii list page is valid without an editor warning', async () => {
	const h = makeHarness({ pageStatus: 'ready' });
	await h.api.checkCurrentPage();
	assert.equal(h.warning.hidden, true);
	assert.equal(h.sentMessages.length, 1);
});

test('stored Miis render by name and update when storage changes', async () => {
	const entries = [
		{ id: 'one', name: '<Mii One>', data: 'aabb', storedAt: 1 },
		{ id: 'two', name: 'Mii Two', data: 'ccdd', storedAt: 2 }
	];
	const h = makeHarness({ storedMiis: entries });
	await h.api.loadStoredMiis();
	assert.equal(h.storedList.hidden, false);
	assert.equal(h.storedEmpty.hidden, true);
	assert.deepEqual(h.storedList.children.map(item => item.children[0].textContent), ['<Mii One>', 'Mii Two']);
	assert.equal(h.storedList.children[0].children[1].attributes['aria-label'], 'Delete stored Mii <Mii One>');
	h.changeStorage([]);
	assert.equal(h.storedList.hidden, true);
	assert.equal(h.storedEmpty.hidden, false);
});

test('cancel preserves a Mii, then delete removes only the selected duplicate-name ID', async () => {
	const entries = [
		{ id: 'one', name: 'Same name', data: 'aabb', storedAt: 1 },
		{ id: 'two', name: 'Same name', data: 'ccdd', storedAt: 2 }
	];
	const h = makeHarness({ storedMiis: entries });
	await h.api.loadStoredMiis();
	h.storedList.children[1].children[1].events.click();
	assert.equal(h.deleteDialog.open, true);
	assert.equal(h.deleteCancel.focused, true);
	h.deleteCancel.events.click();
	assert.equal(h.deleteDialog.open, false);
	assert.equal(h.writes.length, 0);
	h.storedList.children[1].children[1].events.click();
	await h.deleteConfirm.events.click();
	assert.equal(h.deleteDialog.open, false);
	assert.deepEqual(h.stored.get(storedKey).map(entry => entry.id), ['one']);
	assert.equal(h.storedList.children.length, 1);
});

test('a storage write error leaves the confirmation open and the saved Mii intact', async () => {
	const h = makeHarness({ storedMiis: [{ id: 'one', name: 'Mii', data: 'aabb', storedAt: 1 }],
		failSet: true });
	await h.api.loadStoredMiis();
	h.storedList.children[0].children[1].events.click();
	await h.deleteConfirm.events.click();
	assert.equal(h.deleteDialog.open, true);
	assert.equal(h.deleteError.hidden, false);
	assert.equal(h.stored.get(storedKey).length, 1);
	assert.equal(h.deleteConfirm.disabled, false);
});

test('a storage read error shows a stored Mii list error', async () => {
	const h = makeHarness({ failGet: true });
	await h.api.loadStoredMiis();
	assert.equal(h.storedStatus.textContent, 'Could not load stored Miis.');
});
