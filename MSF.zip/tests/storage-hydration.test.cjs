const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const sourcePath = path.join(__dirname, '..', 'content', 'hydrate.js');
const source = fs.readFileSync(sourcePath, 'utf8');
const REQUEST_EVENT = 'mii-studio-fixer:hydrate-request';
const RESULT_EVENT = 'mii-studio-fixer:hydrate-result';
const editorUrl = 'https://studio.mii.nintendo.com/miis/0123456789abcdef/edit?client_id=fedcba9876543210&view=editor';

function createHarness({ canvas = null, storedData = null } = {}) {
	const key = encodeURIComponent(editorUrl);
	const values = new Map();
	if (storedData !== null) {
		values.set(key, storedData);
	}
	const listeners = new Map();
	const results = [];
	const warnings = [];
	let queryCount = 0;
	const document = {
		querySelector(selector) {
			assert.equal(selector, 'canvas#canvas');
			queryCount++;
			return canvas;
		},
		addEventListener(name, listener) {
			const callbacks = listeners.get(name) ?? [];
			callbacks.push(listener);
			listeners.set(name, callbacks);
		},
		dispatchEvent(event) {
			if (event.type === RESULT_EVENT) {
				results.push(event.detail);
			}
			for (const listener of listeners.get(event.type) ?? []) {
				listener(event);
			}
			return true;
		}
	};
	const localStorage = {
		getItem(storageKey) { return values.get(storageKey) ?? null; },
		setItem(storageKey, value) { values.set(storageKey, value); }
	};
	class CustomEvent {
		constructor(type, options = {}) {
			this.type = type;
			this.detail = options.detail;
		}
	}
	vm.runInNewContext(source, {
		CustomEvent,
		console: { warn: (...args) => warnings.push(args) },
		document,
		localStorage,
		location: { href: editorUrl }
	}, { filename: sourcePath });
	return {
		key,
		localStorage,
		results,
		warnings,
		queryCount: () => queryCount,
		request() { document.dispatchEvent({ type: REQUEST_EVENT }); }
	};
}

test('missing storage saves the unchanged current Mii through the editor', () => {
	const mii = { name: 'Current Mii' };
	const calls = [];
	let harness;
	const editor = {
		isPartsPage: true,
		history: { current: mii },
		onPartsUpdated(value) {
			calls.push(value);
			harness.localStorage.setItem(harness.key, 'aabbcc');
		}
	};
	const canvas = { parentElement: { __vue__: { $parent: editor }, parentElement: null } };
	harness = createHarness({ canvas });
	harness.request();
	assert.deepEqual(calls, [mii]);
	assert.strictEqual(calls[0], mii);
	assert.equal(harness.localStorage.getItem(harness.key), 'aabbcc');
	assert.deepEqual(harness.results, ['hydrated']);
});

test('existing exact-page storage is left alone', () => {
	const harness = createHarness({ storedData: 'existing' });
	harness.request();
	assert.equal(harness.localStorage.getItem(harness.key), 'existing');
	assert.equal(harness.queryCount(), 0);
	assert.deepEqual(harness.results, ['already-present']);
});

test('missing editor reports unavailable without writing storage', () => {
	const harness = createHarness();
	harness.request();
	assert.equal(harness.localStorage.getItem(harness.key), null);
	assert.deepEqual(harness.results, ['unavailable']);
});

test('editor outside the parts page is not used', () => {
	const editor = {
		isPartsPage: false,
		history: { current: {} },
		onPartsUpdated() { assert.fail('editor should not save from another page'); }
	};
	const canvas = { __vue__: editor, parentElement: null };
	const harness = createHarness({ canvas });
	harness.request();
	assert.deepEqual(harness.results, ['unavailable']);
});

test('editor failure is reported without fabricating storage data', () => {
	const editor = {
		isPartsPage: true,
		history: { current: {} },
		onPartsUpdated() { throw new Error('save failed'); }
	};
	const canvas = { __vue__: editor, parentElement: null };
	const harness = createHarness({ canvas });
	harness.request();
	assert.equal(harness.localStorage.getItem(harness.key), null);
	assert.deepEqual(harness.results, ['error']);
	assert.equal(harness.warnings.length, 1);
});

test('an editor that cannot populate storage reports no-data after one attempt', () => {
	let attempts = 0;
	const editor = {
		isPartsPage: true,
		history: { current: {} },
		onPartsUpdated() { attempts++; }
	};
	const canvas = { __vue__: editor, parentElement: null };
	const harness = createHarness({ canvas });
	harness.request();
	assert.equal(attempts, 1);
	assert.deepEqual(harness.results, ['no-data']);
});
