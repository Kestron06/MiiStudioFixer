const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const contentDirectory = path.join(__dirname, '..', 'content');
const hydratePath = path.join(contentDirectory, 'hydrate.js');
const previewPath = path.join(contentDirectory, 'preview.js');
const hydrateSource = fs.readFileSync(hydratePath, 'utf8');
const previewSource = fs.readFileSync(previewPath, 'utf8');
const closingIife = '})();';
assert.ok(previewSource.trimEnd().endsWith(closingIife));
const instrumentedPreview = `${previewSource.slice(0, previewSource.lastIndexOf(closingIife))}
	globalThis.__getStudioMiiSnapshot = getStudioMiiSnapshot;
${closingIife}`;

test('preview hydrates the current Mii and reads Nintendo’s exact page URL key', async () => {
	const href = 'https://studio.mii.nintendo.com/miis/0123456789abcdef/edit?client_id=fedcba9876543210&view=editor';
	const exactKey = encodeURIComponent(href);
	const canonicalKey = encodeURIComponent(href.slice(0, href.indexOf('&view=')));
	const mii = { name: 'Unchanged current Mii' };
	const writes = [];
	const requests = [];
	const storedValues = new Map();
	const listeners = new Map();
	const editor = {
		isPartsPage: true,
		history: { current: mii },
		onPartsUpdated(value) {
			writes.push(value);
			storedValues.set(exactKey, 'aabbcc');
		}
	};
	const canvas = { __vue__: { $parent: editor }, parentElement: null };
	const document = {
		querySelector(selector) {
			assert.equal(selector, 'canvas#canvas');
			return canvas;
		},
		addEventListener(name, callback) {
			const callbacks = listeners.get(name) ?? [];
			callbacks.push(callback);
			listeners.set(name, callbacks);
		},
		dispatchEvent(event) {
			if (event.type === 'mii-studio-fixer:hydrate-request') {
				requests.push(event.type);
			}
			for (const callback of listeners.get(event.type) ?? []) {
				callback(event);
			}
			return true;
		}
	};
	const localStorage = {
		getItem(key) { return storedValues.get(key) ?? null; },
		setItem(key, value) { storedValues.set(key, value); }
	};
	class Event {
		constructor(type) { this.type = type; }
	}
	class CustomEvent extends Event {
		constructor(type, options = {}) {
			super(type);
			this.detail = options.detail;
		}
	}
	const shared = {
		CustomEvent,
		Event,
		URL,
		console,
		document,
		localStorage,
		location: { href },
		setTimeout: () => 1,
		clearTimeout() {},
		setInterval: () => 2,
		clearInterval() {},
		requestAnimationFrame: () => 3,
		cancelAnimationFrame() {}
	};
	vm.runInNewContext(hydrateSource, { ...shared }, { filename: hydratePath });
	const isolated = {
		...shared,
		window: { addEventListener() {} },
		chrome: {
			storage: {
				onChanged: { addListener() {} },
				local: { get: async () => ({ 'mii-studio-mii-loader-preview-enabled': true }) }
			}
		}
	};
	vm.runInNewContext(instrumentedPreview, isolated, { filename: previewPath });
	await Promise.resolve();
	await Promise.resolve();

	assert.deepEqual(requests, ['mii-studio-fixer:hydrate-request']);
	assert.equal(writes.length, 1);
	assert.strictEqual(writes[0], mii);
	assert.equal(storedValues.get(exactKey), 'aabbcc');
	assert.equal(storedValues.has(canonicalKey), false);
	const snapshot = isolated.__getStudioMiiSnapshot();
	assert.equal(snapshot.data, 'aabbcc');
	assert.equal(snapshot.fingerprint, `${exactKey}\u0000aabbcc`);
});
